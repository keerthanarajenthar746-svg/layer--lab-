// Layer Lab - Unified Production Bundle with True Generative AI Studio
// Allows direct double-click opening via file:// protocol without any browser CORS issues or dependencies!

(function() {
  'use strict';

  // ==========================================
  // 1. DYNAMIC SVG VECTOR GENERATORS
  // ==========================================
  function generateSneakerSvg(color = '#ef4444', accent = '#18181b') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
      <defs>
        <linearGradient id="snkSole" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#f8fafc" />
          <stop offset="100%" stop-color="#cbd5e1" />
        </linearGradient>
        <filter id="snkShadow">
          <feDropShadow dx="0" dy="18" stdDeviation="16" flood-color="#000" flood-opacity="0.35"/>
        </filter>
      </defs>
      <g filter="url(#snkShadow)">
        <path d="M 70 290 Q 60 270 90 270 L 290 270 Q 340 270 335 300 L 320 315 Q 260 320 180 320 Q 90 320 70 290 Z" fill="url(#snkSole)" stroke="#94a3b8" stroke-width="2"/>
        <path d="M 75 272 L 315 272 Q 330 272 325 290 L 80 290 Z" fill="${accent}"/>
        <path d="M 85 270 C 80 230 110 200 150 190 L 220 140 Q 250 130 270 170 L 305 240 Q 320 270 295 270 Z" fill="${color}"/>
        <path d="M 85 270 Q 75 240 110 235 L 145 270 Z" fill="${accent}" opacity="0.85"/>
        <path d="M 120 245 Q 190 260 260 190 Q 210 240 150 250 Z" fill="#ffffff" opacity="0.95"/>
        <path d="M 210 145 L 245 130 Q 265 140 255 175 Z" fill="${accent}"/>
        <line x1="175" y1="180" x2="215" y2="165" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
        <line x1="185" y1="200" x2="225" y2="185" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
        <line x1="195" y1="220" x2="235" y2="205" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
        <rect x="250" y="295" width="45" height="12" rx="6" fill="#38bdf8" opacity="0.85"/>
      </g>
    </svg>`;
  }

  function generateWatchSvg(metal = '#fbbf24', dial = '#0f172a') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
      <defs>
        <linearGradient id="metalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${metal}" />
          <stop offset="50%" stop-color="#fef08a" />
          <stop offset="100%" stop-color="${metal}" />
        </linearGradient>
        <filter id="watchShadow">
          <feDropShadow dx="0" dy="18" stdDeviation="15" flood-color="#000" flood-opacity="0.38"/>
        </filter>
      </defs>
      <g filter="url(#watchShadow)">
        <path d="M 155 70 L 245 70 L 235 150 L 165 150 Z" fill="#1e293b" stroke="#334155" stroke-width="2"/>
        <line x1="160" y1="90" x2="240" y2="90" stroke="${metal}" stroke-width="2" opacity="0.4"/>
        <line x1="162" y1="110" x2="238" y2="110" stroke="${metal}" stroke-width="2" opacity="0.4"/>
        <path d="M 165 250 L 235 250 L 245 330 L 155 330 Z" fill="#1e293b" stroke="#334155" stroke-width="2"/>
        <line x1="162" y1="290" x2="238" y2="290" stroke="${metal}" stroke-width="2" opacity="0.4"/>
        <line x1="160" y1="310" x2="240" y2="310" stroke="${metal}" stroke-width="2" opacity="0.4"/>
        <rect x="282" y="190" width="16" height="20" rx="3" fill="url(#metalGrad)"/>
        <circle cx="200" cy="200" r="92" fill="url(#metalGrad)" stroke="#78350f" stroke-width="2"/>
        <circle cx="200" cy="200" r="82" fill="${dial}"/>
        <circle cx="200" cy="200" r="76" fill="none" stroke="${metal}" stroke-width="1.5" opacity="0.6"/>
        <circle cx="200" cy="132" r="4" fill="${metal}"/>
        <circle cx="268" cy="200" r="4" fill="${metal}"/>
        <circle cx="200" cy="268" r="4" fill="${metal}"/>
        <circle cx="132" cy="200" r="4" fill="${metal}"/>
        <line x1="200" y1="200" x2="200" y2="148" stroke="url(#metalGrad)" stroke-width="4" stroke-linecap="round"/>
        <line x1="200" y1="200" x2="235" y2="185" stroke="url(#metalGrad)" stroke-width="3" stroke-linecap="round"/>
        <line x1="200" y1="200" x2="180" y2="230" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round"/>
        <circle cx="200" cy="200" r="5" fill="${metal}"/>
      </g>
    </svg>`;
  }

  function generatePerfumeSvg(color = '#f43f5e', accent = '#fbbf24') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
      <defs>
        <linearGradient id="perfGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="${color}" stop-opacity="0.85" />
          <stop offset="50%" stop-color="#ffffff" stop-opacity="0.9" />
          <stop offset="100%" stop-color="${color}" stop-opacity="0.85" />
        </linearGradient>
        <filter id="perfShadow">
          <feDropShadow dx="0" dy="18" stdDeviation="16" flood-color="#000" flood-opacity="0.25"/>
        </filter>
      </defs>
      <g filter="url(#perfShadow)">
        <rect x="175" y="80" width="50" height="55" rx="6" fill="#18181b" stroke="${accent}" stroke-width="2"/>
        <rect x="170" y="135" width="60" height="22" rx="4" fill="${accent}"/>
        <rect x="130" y="157" width="140" height="175" rx="20" fill="url(#perfGrad)" stroke="#ffffff" stroke-width="3"/>
        <path d="M 145 175 L 145 310" stroke="#ffffff" stroke-width="4" stroke-linecap="round" opacity="0.6"/>
        <rect x="150" y="200" width="100" height="85" rx="6" fill="#ffffff" stroke="${accent}" stroke-width="1.5"/>
        <text x="200" y="228" font-family="serif" font-weight="bold" font-size="12" fill="#18181b" text-anchor="middle" letter-spacing="2">PARFUM</text>
        <line x1="165" y1="236" x2="235" y2="236" stroke="${accent}" stroke-width="1"/>
        <text x="200" y="252" font-family="sans-serif" font-size="8" fill="#64748b" text-anchor="middle">EAU DE PARFUM</text>
        <text x="200" y="268" font-family="sans-serif" font-size="8" fill="#94a3b8" text-anchor="middle">50 ML • 1.7 FL OZ</text>
      </g>
    </svg>`;
  }

  function generateCandleSvg(color = '#fed7aa', accent = '#d97706') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
      <defs>
        <radialGradient id="flameGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#fef08a" />
          <stop offset="40%" stop-color="#f59e0b" />
          <stop offset="100%" stop-color="transparent" />
        </radialGradient>
        <filter id="candleShadow">
          <feDropShadow dx="0" dy="18" stdDeviation="15" flood-color="#000" flood-opacity="0.25"/>
        </filter>
      </defs>
      <g filter="url(#candleShadow)">
        <circle cx="200" cy="115" r="45" fill="url(#flameGlow)" opacity="0.6"/>
        <path d="M 200 90 Q 212 115 200 125 Q 188 115 200 90 Z" fill="#fef08a"/>
        <circle cx="200" cy="118" r="4" fill="#ef4444"/>
        <line x1="200" y1="125" x2="200" y2="145" stroke="#1c1917" stroke-width="3" stroke-linecap="round"/>
        <rect x="135" y="145" width="130" height="180" rx="14" fill="#292524" stroke="${accent}" stroke-width="2"/>
        <ellipse cx="200" cy="148" rx="65" ry="12" fill="${color}"/>
        <ellipse cx="200" cy="148" rx="55" ry="8" fill="#ffedd5" opacity="0.7"/>
        <rect x="150" y="195" width="100" height="95" rx="4" fill="#fafaf9"/>
        <text x="200" y="225" font-family="serif" font-weight="bold" font-size="11" fill="#292524" text-anchor="middle" letter-spacing="1.5">SOY CANDLE</text>
        <line x1="165" y1="234" x2="235" y2="234" stroke="${accent}" stroke-width="1"/>
        <text x="200" y="250" font-family="sans-serif" font-size="8" fill="#78716c" text-anchor="middle">AMBER & VANILLA</text>
        <text x="200" y="266" font-family="sans-serif" font-size="7" fill="#a8a29e" text-anchor="middle">60 HR BURN TIME</text>
      </g>
    </svg>`;
  }

  function generateUniversalProductSvg(title = 'Product', color = '#8b5cf6') {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
      <defs>
        <linearGradient id="univGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${color}" />
          <stop offset="100%" stop-color="#090d16" />
        </linearGradient>
        <filter id="univShadow">
          <feDropShadow dx="0" dy="20" stdDeviation="18" flood-color="#000" flood-opacity="0.4"/>
        </filter>
      </defs>
      <g filter="url(#univShadow)">
        <ellipse cx="200" cy="315" rx="100" ry="24" fill="${color}" opacity="0.35"/>
        <ellipse cx="200" cy="310" rx="85" ry="18" fill="#1e293b" stroke="${color}" stroke-width="2"/>
        <rect x="135" y="140" width="130" height="150" rx="18" fill="url(#univGrad)" stroke="#ffffff" stroke-width="2"/>
        <rect x="188" y="140" width="24" height="150" fill="#facc15" opacity="0.9"/>
        <circle cx="200" cy="138" r="16" fill="#eab308"/>
        <circle cx="200" cy="138" r="8" fill="#ca8a04"/>
        <path d="M 120 120 Q 120 135 105 135 Q 120 135 120 150 Q 120 135 135 135 Q 120 135 120 120 Z" fill="#fef08a"/>
        <path d="M 280 125 Q 280 140 265 140 Q 280 140 280 155 Q 280 140 295 140 Q 280 140 280 125 Z" fill="#fef08a"/>
        <rect x="150" y="200" width="100" height="40" rx="8" fill="#000000" opacity="0.65"/>
        <text x="200" y="225" font-family="sans-serif" font-weight="bold" font-size="12" fill="#ffffff" text-anchor="middle">${(title || 'PRODUCT').substring(0, 10).toUpperCase()}</text>
      </g>
    </svg>`;
  }

  // Built-in Catalog Sample Products
  const SAMPLE_PRODUCTS = [
    {
      id: 'prod-handbag',
      name: 'Italian Leather Crossbody',
      category: 'Fashion & Luxury',
      price: '$129.00',
      originalPrice: '$180.00',
      badge: 'NEW ARRIVAL',
      badgeColor: '#e11d48',
      description: 'Full-grain calfskin leather with gold-plated hardware',
      svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="bagGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#b45309" />
            <stop offset="50%" stop-color="#92400e" />
            <stop offset="100%" stop-color="#78350f" />
          </linearGradient>
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#fef08a" />
            <stop offset="50%" stop-color="#eab308" />
            <stop offset="100%" stop-color="#ca8a04" />
          </linearGradient>
          <filter id="bagShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="18" stdDeviation="15" flood-color="#000" flood-opacity="0.35"/>
          </filter>
        </defs>
        <g filter="url(#bagShadow)">
          <path d="M 130 180 C 130 90, 270 90, 270 180" fill="none" stroke="url(#bagGrad)" stroke-width="16" stroke-linecap="round"/>
          <path d="M 130 180 C 130 90, 270 90, 270 180" fill="none" stroke="#fcd34d" stroke-width="2" stroke-dasharray="4,4" opacity="0.6"/>
          <path d="M 90 180 Q 90 160 110 160 L 290 160 Q 310 160 310 180 L 325 310 Q 325 330 300 330 L 100 330 Q 75 330 75 310 Z" fill="url(#bagGrad)"/>
          <path d="M 95 160 L 305 160 L 295 240 Q 200 270 105 240 Z" fill="#78350f" stroke="#451a03" stroke-width="2"/>
          <rect x="185" y="235" width="30" height="25" rx="5" fill="url(#goldGrad)" stroke="#a16207" stroke-width="2"/>
          <circle cx="200" cy="247" r="4" fill="#451a03"/>
          <path d="M 102 165 L 298 165 L 290 234 Q 200 262 110 234 Z" fill="none" stroke="#fde68a" stroke-width="2" stroke-dasharray="4,3" opacity="0.45"/>
          <path d="M 100 180 L 115 310" stroke="#fbbf24" stroke-width="3" stroke-linecap="round" opacity="0.25"/>
        </g>
      </svg>`
    },
    {
      id: 'prod-coffee',
      name: 'Artisan Ethiopian Roast',
      category: 'Coffee & Pantry',
      price: '$21.50',
      originalPrice: '$26.00',
      badge: 'SINGLE ORIGIN',
      badgeColor: '#15803d',
      description: 'Floral jasmine, bergamot notes, washed medium roast',
      svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="pouchGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#262626" />
            <stop offset="50%" stop-color="#404040" />
            <stop offset="100%" stop-color="#1f1f1f" />
          </linearGradient>
          <filter id="pouchShadow">
            <feDropShadow dx="0" dy="16" stdDeviation="14" flood-color="#000" flood-opacity="0.3"/>
          </filter>
        </defs>
        <g filter="url(#pouchShadow)">
          <path d="M 120 90 L 280 90 L 295 120 L 305 330 Q 305 340 290 340 L 110 340 Q 95 340 95 330 L 105 120 Z" fill="url(#pouchGrad)"/>
          <rect x="115" y="80" width="170" height="15" rx="3" fill="#171717"/>
          <line x1="115" y1="87" x2="285" y2="87" stroke="#525252" stroke-width="2" stroke-dasharray="3,3"/>
          <rect x="135" y="145" width="130" height="155" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="1.5"/>
          <circle cx="200" cy="180" r="16" fill="#b45309"/>
          <text x="200" y="185" font-family="sans-serif" font-weight="900" font-size="14" fill="#ffffff" text-anchor="middle">☕</text>
          <text x="200" y="215" font-family="sans-serif" font-weight="bold" font-size="12" fill="#78350f" text-anchor="middle" letter-spacing="1">YIRGACHEFFE</text>
          <text x="200" y="232" font-family="sans-serif" font-size="9" fill="#92400e" text-anchor="middle">WHOLE BEAN • 340G</text>
          <line x1="150" y1="245" x2="250" y2="245" stroke="#d97706" stroke-width="1" opacity="0.4"/>
          <text x="200" y="265" font-family="sans-serif" font-weight="bold" font-size="10" fill="#451a03" text-anchor="middle">NOTES: CITRUS & HONEY</text>
          <text x="200" y="283" font-family="sans-serif" font-size="8" fill="#78350f" text-anchor="middle">ROASTED WITH CARE</text>
        </g>
      </svg>`
    },
    {
      id: 'prod-headphones',
      name: 'AeroTune Pro ANC',
      category: 'Electronics & Tech',
      price: '$249.99',
      originalPrice: '$299.99',
      badge: 'BEST SELLER',
      badgeColor: '#2563eb',
      description: 'Active Noise Canceling with 40hr Battery & Spatial Audio',
      svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="hpHeadband" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#475569" />
            <stop offset="100%" stop-color="#0f172a" />
          </linearGradient>
          <linearGradient id="hpCup" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#334155" />
            <stop offset="70%" stop-color="#0f172a" />
            <stop offset="100%" stop-color="#020617" />
          </linearGradient>
          <filter id="hpGlow">
            <feDropShadow dx="0" dy="16" stdDeviation="16" flood-color="#000" flood-opacity="0.35"/>
          </filter>
        </defs>
        <g filter="url(#hpGlow)">
          <path d="M 120 220 C 120 100, 280 100, 280 220" fill="none" stroke="url(#hpHeadband)" stroke-width="26" stroke-linecap="round"/>
          <path d="M 140 160 C 140 115, 260 115, 260 160" fill="none" stroke="#1e293b" stroke-width="8" opacity="0.6"/>
          <rect x="95" y="200" width="14" height="40" rx="4" fill="#94a3b8"/>
          <rect x="291" y="200" width="14" height="40" rx="4" fill="#94a3b8"/>
          <ellipse cx="102" cy="255" rx="34" ry="52" fill="url(#hpCup)" stroke="#64748b" stroke-width="2"/>
          <ellipse cx="102" cy="255" rx="22" ry="38" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="6,4"/>
          <ellipse cx="298" cy="255" rx="34" ry="52" fill="url(#hpCup)" stroke="#64748b" stroke-width="2"/>
          <ellipse cx="298" cy="255" rx="22" ry="38" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="6,4"/>
          <circle cx="298" cy="275" r="3" fill="#38bdf8"/>
        </g>
      </svg>`
    },
    {
      id: 'prod-serum',
      name: 'Glow Botanical Face Elixir',
      category: 'Beauty & Skincare',
      price: '$44.00',
      originalPrice: '$55.00',
      badge: '100% ORGANIC',
      badgeColor: '#059669',
      description: 'Cold-pressed Rosehip, Squalane & Vitamin C radiance serum',
      svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="amberGlass" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#d97706" />
            <stop offset="30%" stop-color="#f59e0b" />
            <stop offset="70%" stop-color="#b45309" />
            <stop offset="100%" stop-color="#78350f" />
          </linearGradient>
          <filter id="serumShadow">
            <feDropShadow dx="0" dy="16" stdDeviation="14" flood-color="#000" flood-opacity="0.25"/>
          </filter>
        </defs>
        <g filter="url(#serumShadow)">
          <path d="M 185 85 Q 200 65 215 85 L 215 105 L 185 105 Z" fill="#18181b"/>
          <rect x="178" y="105" width="44" height="20" rx="3" fill="#facc15" stroke="#ca8a04" stroke-width="1"/>
          <rect x="180" y="125" width="40" height="10" fill="#18181b"/>
          <rect x="182" y="135" width="36" height="15" fill="#92400e"/>
          <rect x="145" y="150" width="110" height="175" rx="18" fill="url(#amberGlass)"/>
          <path d="M 155 160 Q 150 230 155 310" stroke="#fef3c7" stroke-width="4" stroke-linecap="round" opacity="0.4"/>
          <rect x="155" y="195" width="90" height="95" rx="4" fill="#fafaf9" stroke="#e5e5e5" stroke-width="1"/>
          <text x="200" y="222" font-family="serif" font-weight="bold" font-size="12" fill="#292524" text-anchor="middle" letter-spacing="2">LUMEN</text>
          <text x="200" y="238" font-family="sans-serif" font-size="8" fill="#78716c" text-anchor="middle">FACIAL SERUM</text>
          <line x1="175" y1="248" x2="225" y2="248" stroke="#d6d3d1" stroke-width="1"/>
          <text x="200" y="264" font-family="sans-serif" font-size="7" fill="#059669" text-anchor="middle" font-weight="600">VITAMIN C + SQUALANE</text>
          <text x="200" y="278" font-family="sans-serif" font-size="7" fill="#a8a29e" text-anchor="middle">30 ML / 1.0 FL OZ</text>
        </g>
      </svg>`
    },
    {
      id: 'prod-ceramic',
      name: 'Wabi-Sabi Stoneware Mug',
      category: 'Home & Ceramics',
      price: '$36.00',
      originalPrice: '$42.00',
      badge: 'HANDCRAFTED',
      badgeColor: '#d97706',
      description: 'Wheel-thrown speckled clay with toasted iron-fleck glaze',
      svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="clayGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#e7e5e4" />
            <stop offset="45%" stop-color="#fafaf9" />
            <stop offset="85%" stop-color="#d6d3d1" />
            <stop offset="100%" stop-color="#a8a29e" />
          </linearGradient>
          <filter id="mugShadow">
            <feDropShadow dx="0" dy="16" stdDeviation="15" flood-color="#000" flood-opacity="0.25"/>
          </filter>
        </defs>
        <g filter="url(#mugShadow)">
          <path d="M 270 180 C 345 180, 345 280, 270 280" fill="none" stroke="#d6d3d1" stroke-width="22" stroke-linecap="round"/>
          <path d="M 270 180 C 345 180, 345 280, 270 280" fill="none" stroke="#78716c" stroke-width="4" opacity="0.3"/>
          <path d="M 125 150 Q 120 320 150 325 L 260 325 Q 290 320 285 150 Z" fill="url(#clayGrad)"/>
          <path d="M 143 295 L 267 295 L 260 325 Q 205 330 150 325 Z" fill="#b45309" opacity="0.85"/>
          <ellipse cx="205" cy="150" rx="80" ry="16" fill="#f5f5f4" stroke="#a8a29e" stroke-width="1.5"/>
          <ellipse cx="205" cy="150" rx="72" ry="12" fill="#78350f" opacity="0.15"/>
          <circle cx="160" cy="190" r="2.5" fill="#78350f" opacity="0.6"/>
          <circle cx="230" cy="210" r="1.8" fill="#78350f" opacity="0.5"/>
          <circle cx="180" cy="250" r="3" fill="#78350f" opacity="0.7"/>
          <circle cx="215" cy="270" r="2" fill="#78350f" opacity="0.6"/>
          <circle cx="250" cy="180" r="1.5" fill="#78350f" opacity="0.5"/>
        </g>
      </svg>`
    }
  ];

  function svgToDataUrl(svgString) {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgString);
  }

  // ==========================================
  // 2. BRAND TEMPLATES & THEMES
  // ==========================================
  const BRAND_TEMPLATES = [
    {
      id: 'theme-luxury',
      name: 'Velvet & Gold',
      category: 'Fashion & Luxury',
      aspectRatio: '1:1',
      brand: {
        name: 'MAISON ÉLÉGANCE',
        tagline: 'PARIS • MILAN • NEW YORK',
        handle: '@maisonelegance • www.maisonelegance.com',
        fontFamily: `'Playfair Display', serif`,
        fontHeader: `'Cinzel', serif`,
        textColor: '#ffffff',
        accentColor: '#d4af37',
        badgeBgColor: '#d4af37',
        badgeTextColor: '#000000',
        backgroundType: 'gradient',
        bgGradientStart: '#18181b',
        bgGradientEnd: '#09090b',
        frameStyle: 'ornate-border',
        watermarkText: 'ÉLÉGANCE COUTURE',
        showWatermark: true,
        logoMonogram: 'ME',
        badgePlacement: 'top-right'
      },
      defaultProduct: {
        name: 'Italian Leather Crossbody',
        price: '$129.00',
        originalPrice: '$180.00',
        badge: 'LIMITED EDITION',
        description: 'Hand-stitched calfskin with brushed gold hardware',
        sampleId: 'prod-handbag',
        scale: 0.95,
        posX: 0,
        posY: 10
      }
    },
    {
      id: 'theme-nordic',
      name: 'Nordic Roast',
      category: 'Cafe & Pantry',
      aspectRatio: '1:1',
      brand: {
        name: 'FJORD COFFEE ROASTERS',
        tagline: 'ORGANIC SMALL-BATCH SPECIALTY BEANS',
        handle: '@fjordroasters • fjordcoffee.co',
        fontFamily: `'Plus Jakarta Sans', sans-serif`,
        fontHeader: `'Space Grotesk', sans-serif`,
        textColor: '#292524',
        accentColor: '#b45309',
        badgeBgColor: '#15803d',
        badgeTextColor: '#ffffff',
        backgroundType: 'warm-cream',
        bgGradientStart: '#fef3c7',
        bgGradientEnd: '#fde68a',
        frameStyle: 'minimal-frame',
        watermarkText: 'EST. 2018',
        showWatermark: true,
        logoMonogram: '☕ FJ',
        badgePlacement: 'top-left'
      },
      defaultProduct: {
        name: 'Artisan Ethiopian Roast',
        price: '$21.50',
        originalPrice: '$26.00',
        badge: 'FRESH ROAST',
        description: 'Floral jasmine, bergamot notes, washed medium roast',
        sampleId: 'prod-coffee',
        scale: 0.92,
        posX: 0,
        posY: 15
      }
    },
    {
      id: 'theme-tech',
      name: 'Cyber Pulse',
      category: 'Tech & Gaming',
      aspectRatio: '1:1',
      brand: {
        name: 'NEXUS SOUND LABS',
        tagline: 'NEXT-GEN ACOUSTIC ARCHITECTURE',
        handle: '@nexussound • shopnexus.io',
        fontFamily: `'Inter', sans-serif`,
        fontHeader: `'Space Grotesk', sans-serif`,
        textColor: '#f8fafc',
        accentColor: '#38bdf8',
        badgeBgColor: '#2563eb',
        badgeTextColor: '#ffffff',
        backgroundType: 'neon-dark',
        bgGradientStart: '#0f172a',
        bgGradientEnd: '#020617',
        frameStyle: 'modern-card',
        watermarkText: 'NEXUS AUDIO',
        showWatermark: true,
        logoMonogram: '⟐ NX',
        badgePlacement: 'top-right'
      },
      defaultProduct: {
        name: 'AeroTune Pro ANC',
        price: '$249.99',
        originalPrice: '$299.99',
        badge: 'FLASH SALE',
        description: 'Active Noise Canceling with 40hr Battery & Spatial Audio',
        sampleId: 'prod-headphones',
        scale: 0.95,
        posX: 0,
        posY: 10
      }
    },
    {
      id: 'theme-botanical',
      name: 'Botanical Glow',
      category: 'Skincare & Wellness',
      aspectRatio: '1:1',
      brand: {
        name: 'LUMEN BOTANICALS',
        tagline: 'PURE PLANT ALCHEMY FOR RADIANT SKIN',
        handle: '@lumenbotanicals • lumenbotanicals.com',
        fontFamily: `'Playfair Display', serif`,
        fontHeader: `'Playfair Display', serif`,
        textColor: '#1c1917',
        accentColor: '#059669',
        badgeBgColor: '#059669',
        badgeTextColor: '#ffffff',
        backgroundType: 'sage-light',
        bgGradientStart: '#f0fdf4',
        bgGradientEnd: '#dcfce7',
        frameStyle: 'ornate-border',
        watermarkText: 'CLEAN BEAUTY',
        showWatermark: true,
        logoMonogram: '🌿 LM',
        badgePlacement: 'top-left'
      },
      defaultProduct: {
        name: 'Glow Face Elixir Serum',
        price: '$44.00',
        originalPrice: '$55.00',
        badge: 'BEST SELLER',
        description: 'Cold-pressed Rosehip, Squalane & Vitamin C radiance serum',
        sampleId: 'prod-serum',
        scale: 0.95,
        posX: 0,
        posY: 12
      }
    },
    {
      id: 'theme-artisan',
      name: 'Earth & Clay',
      category: 'Crafts & Ceramics',
      aspectRatio: '1:1',
      brand: {
        name: 'TERRA STUDIO CO.',
        tagline: 'SMALL BATCH HANDMADE STONEWARE',
        handle: '@terrastudio • terraceramics.store',
        fontFamily: `'Plus Jakarta Sans', sans-serif`,
        fontHeader: `'Playfair Display', serif`,
        textColor: '#292524',
        accentColor: '#d97706',
        badgeBgColor: '#d97706',
        badgeTextColor: '#ffffff',
        backgroundType: 'terracotta-warm',
        bgGradientStart: '#fff7ed',
        bgGradientEnd: '#ffedd5',
        frameStyle: 'minimal-frame',
        watermarkText: 'POTTERY WORKS',
        showWatermark: true,
        logoMonogram: '🏺 TS',
        badgePlacement: 'top-right'
      },
      defaultProduct: {
        name: 'Wabi-Sabi Stoneware Mug',
        price: '$36.00',
        originalPrice: '$42.00',
        badge: 'HANDCRAFTED',
        description: 'Wheel-thrown speckled clay with toasted iron-fleck glaze',
        sampleId: 'prod-ceramic',
        scale: 0.95,
        posX: 0,
        posY: 10
      }
    }
  ];

  // ==========================================
  // 3. SCOPED UNDO / REDO ENGINE
  // ==========================================
  class HistoryManager {
    constructor(options = {}) {
      this.maxHistory = options.maxHistory || 40;
      this.productUndoStack = [];
      this.productRedoStack = [];
      this.brandUndoStack = [];
      this.brandRedoStack = [];
      this.onHistoryChange = options.onHistoryChange || (() => {});
      this.onToast = options.onToast || (() => {});
    }

    clone(state) {
      return JSON.parse(JSON.stringify(state));
    }

    pushProductState(label, productState) {
      this.productUndoStack.push({
        label,
        state: this.clone(productState),
        timestamp: Date.now()
      });
      if (this.productUndoStack.length > this.maxHistory) {
        this.productUndoStack.shift();
      }
      this.productRedoStack = [];
      this.notify();
    }

    pushBrandState(label, brandState) {
      this.brandUndoStack.push({
        label,
        state: this.clone(brandState),
        timestamp: Date.now()
      });
      if (this.brandUndoStack.length > this.maxHistory) {
        this.brandUndoStack.shift();
      }
      this.brandRedoStack = [];
      this.notify();
    }

    undo(isBrandModeUnlocked) {
      if (isBrandModeUnlocked) {
        if (this.brandUndoStack.length <= 1) {
          this.onToast('No earlier brand changes to undo', 'info');
          return null;
        }
        const current = this.brandUndoStack.pop();
        this.brandRedoStack.push(current);
        const previous = this.brandUndoStack[this.brandUndoStack.length - 1];
        this.notify();
        this.onToast(`Undid: ${current.label} (Brand Mode)`, 'info');
        return { type: 'brand', state: this.clone(previous.state) };
      } else {
        if (this.productUndoStack.length <= 1) {
          this.onToast('No earlier product changes to undo', 'info');
          return null;
        }
        const current = this.productUndoStack.pop();
        this.productRedoStack.push(current);
        const previous = this.productUndoStack[this.productUndoStack.length - 1];
        this.notify();
        this.onToast(`Undid: ${current.label} (🛡️ Brand Kept Static)`, 'success');
        return { type: 'product', state: this.clone(previous.state) };
      }
    }

    redo(isBrandModeUnlocked) {
      if (isBrandModeUnlocked) {
        if (this.brandRedoStack.length === 0) {
          this.onToast('Nothing to redo in Brand Mode', 'info');
          return null;
        }
        const next = this.brandRedoStack.pop();
        this.brandUndoStack.push(next);
        this.notify();
        this.onToast(`Redid: ${next.label} (Brand Mode)`, 'info');
        return { type: 'brand', state: this.clone(next.state) };
      } else {
        if (this.productRedoStack.length === 0) {
          this.onToast('Nothing to redo in Product Mode', 'info');
          return null;
        }
        const next = this.productRedoStack.pop();
        this.productUndoStack.push(next);
        this.notify();
        this.onToast(`Redid: ${next.label} (🛡️ Brand Kept Static)`, 'success');
        return { type: 'product', state: this.clone(next.state) };
      }
    }

    canUndo(isBrandModeUnlocked) {
      if (isBrandModeUnlocked) return this.brandUndoStack.length > 1;
      return this.productUndoStack.length > 1;
    }

    canRedo(isBrandModeUnlocked) {
      if (isBrandModeUnlocked) return this.brandRedoStack.length > 0;
      return this.productRedoStack.length > 0;
    }

    getHistoryLogs(isBrandModeUnlocked) {
      const list = isBrandModeUnlocked ? this.brandUndoStack : this.productUndoStack;
      return list.slice().reverse().map((item, idx) => ({
        index: list.length - 1 - idx,
        isCurrent: idx === 0,
        label: item.label,
        time: new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      }));
    }

    notify() {
      this.onHistoryChange({
        canUndoProduct: this.productUndoStack.length > 1,
        canRedoProduct: this.productRedoStack.length > 0,
        canUndoBrand: this.brandUndoStack.length > 1,
        canRedoBrand: this.brandRedoStack.length > 0,
        productCount: this.productUndoStack.length,
        brandCount: this.brandUndoStack.length
      });
    }
  }

  // ==========================================
  // 4. CANVAS RENDERING ENGINE
  // ==========================================
  class CanvasEngine {
    constructor(canvasElement, options = {}) {
      this.canvas = canvasElement;
      this.ctx = canvasElement.getContext('2d');
      this.baseWidth = 1080;
      this.baseHeight = 1080;

      this.brandState = null;
      this.productState = null;
      this.isBrandModeUnlocked = false;

      this.selectedElement = 'product-image';
      this.isDragging = false;
      this.isResizing = false;
      this.dragStart = { x: 0, y: 0 };
      this.activeHandle = null;

      this.imageCache = new Map();
      this.onStateModified = options.onStateModified || (() => {});
      this.onSelectionChange = options.onSelectionChange || (() => {});

      this.setupInteractions();
    }

    setDimensions(width, height) {
      this.baseWidth = width;
      this.baseHeight = height;
      this.resizeCanvas();
      this.requestRender();
    }

    resizeCanvas() {
      const dpr = window.devicePixelRatio || 1;
      const rect = this.canvas.getBoundingClientRect();
      this.canvas.width = rect.width * dpr;
      this.canvas.height = rect.height * dpr;
    }

    setState(brandState, productState, isBrandModeUnlocked = false) {
      this.brandState = brandState;
      this.productState = productState;
      this.isBrandModeUnlocked = isBrandModeUnlocked;
      this.requestRender();
    }

    requestRender() {
      requestAnimationFrame(() => this.render(false));
    }

    async loadImage(src) {
      if (!src) return null;
      if (this.imageCache.has(src)) return this.imageCache.get(src);

      return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          this.imageCache.set(src, img);
          resolve(img);
        };
        img.onerror = () => resolve(null);
        img.src = src;
      });
    }

    getCanvasCoords(e) {
      const rect = this.canvas.getBoundingClientRect();
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      const clientY = e.clientY || (e.touches && e.touches[0].clientY);
      const x = ((clientX - rect.left) / rect.width) * this.baseWidth;
      const y = ((clientY - rect.top) / rect.height) * this.baseHeight;
      return { x, y };
    }

    setupInteractions() {
      const handleDown = (e) => {
        const coords = this.getCanvasCoords(e);
        const hit = this.hitTest(coords.x, coords.y);

        if (hit) {
          if (hit.handle) {
            this.isResizing = true;
            this.activeHandle = hit.handle;
          } else {
            this.isDragging = true;
            this.selectedElement = hit.element;
            this.onSelectionChange(this.selectedElement);
          }
          this.dragStart = coords;
          this.requestRender();
        } else {
          this.selectedElement = null;
          this.onSelectionChange(null);
          this.requestRender();
        }
      };

      const handleMove = (e) => {
        const coords = this.getCanvasCoords(e);

        if (this.isDragging && this.selectedElement) {
          const dx = coords.x - this.dragStart.x;
          const dy = coords.y - this.dragStart.y;

          if (this.selectedElement === 'product-image') {
            this.productState.posX = (this.productState.posX || 0) + dx;
            this.productState.posY = (this.productState.posY || 0) + dy;
          } else if (this.selectedElement === 'product-price') {
            this.productState.pricePosX = (this.productState.pricePosX || 0) + dx;
            this.productState.pricePosY = (this.productState.pricePosY || 0) + dy;
          } else if (this.selectedElement === 'product-badge') {
            this.productState.badgePosX = (this.productState.badgePosX || 0) + dx;
            this.productState.badgePosY = (this.productState.badgePosY || 0) + dy;
          }

          this.dragStart = coords;
          this.requestRender();
        } else if (this.isResizing && this.selectedElement === 'product-image') {
          const dx = coords.x - this.dragStart.x;
          const scaleDelta = dx / 350;
          const newScale = Math.min(Math.max(0.4, (this.productState.scale || 1) + scaleDelta), 2.2);
          this.productState.scale = newScale;
          this.dragStart = coords;
          this.requestRender();
        } else {
          const hit = this.hitTest(coords.x, coords.y);
          if (hit && hit.handle) {
            this.canvas.style.cursor = 'nwse-resize';
          } else if (hit) {
            this.canvas.style.cursor = 'move';
          } else {
            this.canvas.style.cursor = 'default';
          }
        }
      };

      const handleUp = () => {
        if (this.isDragging || this.isResizing) {
          this.isDragging = false;
          this.isResizing = false;
          this.activeHandle = null;
          this.onStateModified('Adjusted Product Layout');
        }
      };

      this.canvas.addEventListener('mousedown', handleDown);
      window.addEventListener('mousemove', handleMove);
      window.addEventListener('mouseup', handleUp);

      this.canvas.addEventListener('touchstart', (e) => {
        e.preventDefault();
        handleDown(e);
      }, { passive: false });

      window.addEventListener('touchmove', (e) => {
        if (this.isDragging || this.isResizing) e.preventDefault();
        handleMove(e);
      }, { passive: false });

      window.addEventListener('touchend', handleUp);
    }

    hitTest(x, y) {
      if (!this.productState) return null;

      if (this.selectedElement === 'product-image') {
        const bounds = this.getProductImageBounds();
        const handleRadius = 24;
        const brX = bounds.x + bounds.w;
        const brY = bounds.y + bounds.h;
        if (Math.hypot(x - brX, y - brY) <= handleRadius) {
          return { handle: 'br', element: 'product-image' };
        }
      }

      const pBounds = this.getProductImageBounds();
      if (x >= pBounds.x && x <= pBounds.x + pBounds.w && y >= pBounds.y && y <= pBounds.y + pBounds.h) {
        return { element: 'product-image' };
      }

      const priceBounds = this.getPriceBounds();
      if (x >= priceBounds.x && x <= priceBounds.x + priceBounds.w && y >= priceBounds.y && y <= priceBounds.y + priceBounds.h) {
        return { element: 'product-price' };
      }

      const badgeBounds = this.getBadgeBounds();
      if (x >= badgeBounds.x && x <= badgeBounds.x + badgeBounds.w && y >= badgeBounds.y && y <= badgeBounds.y + badgeBounds.h) {
        return { element: 'product-badge' };
      }

      return null;
    }

    getProductImageBounds() {
      const scale = this.productState.scale || 1.0;
      const baseW = 540 * scale;
      const baseH = 540 * scale;
      const cx = (this.baseWidth / 2) + (this.productState.posX || 0);
      const cy = (this.baseHeight * 0.46) + (this.productState.posY || 0);
      return { x: cx - baseW / 2, y: cy - baseH / 2, w: baseW, h: baseH, cx, cy };
    }

    getPriceBounds() {
      const defX = this.baseWidth / 2 + (this.productState.pricePosX || 0);
      const defY = this.baseHeight * 0.77 + (this.productState.pricePosY || 0);
      const w = 340;
      const h = 75;
      return { x: defX - w / 2, y: defY - h / 2, w, h };
    }

    getBadgeBounds() {
      const placement = this.brandState?.badgePlacement || 'top-right';
      let defX = placement === 'top-left' ? 140 : this.baseWidth - 140;
      let defY = 220;
      defX += (this.productState.badgePosX || 0);
      defY += (this.productState.badgePosY || 0);
      const w = 220;
      const h = 54;
      return { x: defX - w / 2, y: defY - h / 2, w, h };
    }

    async render(isExport = false) {
      if (!this.brandState || !this.productState) return;

      const ctx = this.ctx;
      const rect = this.canvas.getBoundingClientRect();
      const dpr = isExport ? 2 : (window.devicePixelRatio || 1);

      if (isExport) {
        this.canvas.width = this.baseWidth * 2;
        this.canvas.height = this.baseHeight * 2;
        ctx.scale(2, 2);
      } else {
        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        ctx.scale(this.canvas.width / this.baseWidth, this.canvas.height / this.baseHeight);
      }

      ctx.clearRect(0, 0, this.baseWidth, this.baseHeight);

      // Layer 1: Brand Master Layer (Static)
      this.renderBrandLayer(ctx);

      // Layer 2: Product Dynamic Layer
      await this.renderProductLayer(ctx);

      // Selection handles
      if (!isExport && this.selectedElement) {
        this.renderSelectionOutline(ctx);
      }
    }

    renderBrandLayer(ctx) {
      const b = this.brandState;
      const W = this.baseWidth;
      const H = this.baseHeight;

      if (b.backgroundType === 'gradient' || b.bgGradientStart) {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, b.bgGradientStart || '#18181b');
        grad.addColorStop(1, b.bgGradientEnd || '#09090b');
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = b.bgGradientStart || '#18181b';
      }
      ctx.fillRect(0, 0, W, H);

      // Subtle radial glow
      const radial = ctx.createRadialGradient(W / 2, H * 0.45, 80, W / 2, H * 0.45, 600);
      radial.addColorStop(0, `${b.accentColor}18`);
      radial.addColorStop(1, 'transparent');
      ctx.fillStyle = radial;
      ctx.fillRect(0, 0, W, H);

      // Brand Frame
      this.renderBrandFrame(ctx, b, W, H);

      // Brand Header
      ctx.save();
      ctx.textAlign = 'center';

      if (b.logoMonogram) {
        ctx.fillStyle = b.accentColor;
        ctx.font = `600 24px ${b.fontHeader || 'sans-serif'}`;
        ctx.fillText(b.logoMonogram.toUpperCase(), W / 2, 85);
      }

      ctx.fillStyle = b.textColor || '#ffffff';
      ctx.font = `700 38px ${b.fontFamily || 'serif'}`;
      ctx.shadowColor = 'rgba(0,0,0,0.3)';
      ctx.shadowBlur = 6;
      ctx.fillText(b.name.toUpperCase(), W / 2, 130);
      ctx.shadowBlur = 0;

      ctx.fillStyle = `${b.textColor}99`;
      ctx.font = `500 15px ${b.fontHeader || 'sans-serif'}`;
      ctx.letterSpacing = '3px';
      ctx.fillText(b.tagline.toUpperCase(), W / 2, 158);
      ctx.restore();

      // Watermark
      if (b.showWatermark && b.watermarkText) {
        ctx.save();
        ctx.translate(W * 0.88, H * 0.38);
        ctx.rotate(-Math.PI / 2);
        ctx.textAlign = 'center';
        ctx.font = `700 13px ${b.fontHeader || 'sans-serif'}`;
        ctx.fillStyle = `${b.textColor}22`;
        ctx.fillText(b.watermarkText.toUpperCase(), 0, 0);
        ctx.restore();
      }

      // Brand Footer
      ctx.save();
      ctx.strokeStyle = `${b.accentColor}40`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(W * 0.2, H - 75);
      ctx.lineTo(W * 0.8, H - 75);
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.fillStyle = `${b.textColor}bb`;
      ctx.font = `500 16px ${b.fontHeader || 'sans-serif'}`;
      ctx.fillText(b.handle, W / 2, H - 45);
      ctx.restore();
    }

    renderBrandFrame(ctx, b, W, H) {
      const style = b.frameStyle || 'ornate-border';
      ctx.save();

      if (style === 'ornate-border') {
        ctx.strokeStyle = `${b.accentColor}55`;
        ctx.lineWidth = 2;
        ctx.strokeRect(35, 35, W - 70, H - 70);

        ctx.strokeStyle = `${b.accentColor}25`;
        ctx.lineWidth = 1;
        ctx.strokeRect(45, 45, W - 90, H - 90);

        const cornerSize = 25;
        ctx.strokeStyle = b.accentColor;
        ctx.lineWidth = 3;

        ctx.beginPath();
        ctx.moveTo(35, 35 + cornerSize);
        ctx.lineTo(35, 35);
        ctx.lineTo(35 + cornerSize, 35);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(W - 35 - cornerSize, 35);
        ctx.lineTo(W - 35, 35);
        ctx.lineTo(W - 35, 35 + cornerSize);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(35, H - 35 - cornerSize);
        ctx.lineTo(35, H - 35);
        ctx.lineTo(35 + cornerSize, H - 35);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(W - 35 - cornerSize, H - 35);
        ctx.lineTo(W - 35, H - 35);
        ctx.lineTo(W - 35, H - 35 - cornerSize);
        ctx.stroke();
      } else if (style === 'minimal-frame') {
        ctx.strokeStyle = `${b.accentColor}44`;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(40, 40, W - 80, H - 80);
      } else if (style === 'modern-card') {
        ctx.strokeStyle = `${b.accentColor}33`;
        ctx.lineWidth = 2;
        this.drawRoundedRect(ctx, 30, 30, W - 60, H - 60, 24);
        ctx.stroke();
      }

      ctx.restore();
    }

    async renderProductLayer(ctx) {
      const p = this.productState;
      const b = this.brandState;
      const W = this.baseWidth;
      const H = this.baseHeight;

      // Product Image
      const bounds = this.getProductImageBounds();
      const imgSrc = p.imageUrl || p.svgDataUrl;

      if (imgSrc) {
        const img = await this.loadImage(imgSrc);
        if (img) {
          ctx.save();
          ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
          ctx.shadowBlur = 28;
          ctx.shadowOffsetY = 18;
          ctx.drawImage(img, bounds.x, bounds.y, bounds.w, bounds.h);
          ctx.restore();
        }
      }

      // Promotional Badge
      if (p.badge) {
        const badgeBounds = this.getBadgeBounds();
        ctx.save();
        const badgeBg = p.badgeColor || b.badgeBgColor || b.accentColor;
        const badgeText = p.badgeTextColor || b.badgeTextColor || '#ffffff';

        ctx.shadowColor = 'rgba(0,0,0,0.3)';
        ctx.shadowBlur = 12;
        ctx.shadowOffsetY = 4;

        ctx.fillStyle = badgeBg;
        this.drawRoundedRect(ctx, badgeBounds.x, badgeBounds.y, badgeBounds.w, badgeBounds.h, 27);
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.fillStyle = badgeText;
        ctx.font = `700 16px ${b.fontHeader || 'sans-serif'}`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(p.badge.toUpperCase(), badgeBounds.x + badgeBounds.w / 2, badgeBounds.y + badgeBounds.h / 2);
        ctx.restore();
      }

      // Product Title & Description
      ctx.save();
      ctx.textAlign = 'center';
      ctx.fillStyle = b.textColor || '#ffffff';
      ctx.font = `700 32px ${b.fontFamily || 'serif'}`;
      const titleY = H * 0.70 + (p.posY || 0) * 0.3;
      ctx.fillText(p.name, W / 2, titleY);

      if (p.description) {
        ctx.fillStyle = `${b.textColor}aa`;
        ctx.font = `400 16px ${b.fontHeader || 'sans-serif'}`;
        ctx.fillText(p.description, W / 2, titleY + 30);
      }
      ctx.restore();

      // Price Tag Pill
      if (p.price) {
        const pb = this.getPriceBounds();
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.strokeStyle = `${b.accentColor}66`;
        ctx.lineWidth = 1.5;
        this.drawRoundedRect(ctx, pb.x, pb.y, pb.w, pb.h, 38);
        ctx.fill();
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = b.accentColor || '#ffffff';
        ctx.font = `800 30px ${b.fontHeader || 'sans-serif'}`;

        if (p.originalPrice) {
          ctx.textAlign = 'left';
          const startX = pb.x + 35;
          ctx.fillText(p.price, startX, pb.y + pb.h / 2);

          ctx.fillStyle = `${b.textColor}66`;
          ctx.font = `500 20px ${b.fontHeader || 'sans-serif'}`;
          const strikeX = startX + ctx.measureText(p.price).width + 30;
          ctx.fillText(p.originalPrice, strikeX, pb.y + pb.h / 2);

          const strikeW = ctx.measureText(p.originalPrice).width;
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(strikeX - 2, pb.y + pb.h / 2);
          ctx.lineTo(strikeX + strikeW + 2, pb.y + pb.h / 2);
          ctx.stroke();
        } else {
          ctx.fillText(p.price, pb.x + pb.w / 2, pb.y + pb.h / 2);
        }
        ctx.restore();
      }
    }

    renderSelectionOutline(ctx) {
      let bounds = null;
      if (this.selectedElement === 'product-image') bounds = this.getProductImageBounds();
      else if (this.selectedElement === 'product-price') bounds = this.getPriceBounds();
      else if (this.selectedElement === 'product-badge') bounds = this.getBadgeBounds();

      if (!bounds) return;

      ctx.save();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 6]);
      ctx.strokeRect(bounds.x - 6, bounds.y - 6, bounds.w + 12, bounds.h + 12);
      ctx.setLineDash([]);

      if (this.selectedElement === 'product-image') {
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#0284c7';
        ctx.lineWidth = 2;
        const hSize = 14;
        const brX = bounds.x + bounds.w + 6;
        const brY = bounds.y + bounds.h + 6;
        ctx.fillRect(brX - hSize / 2, brY - hSize / 2, hSize, hSize);
        ctx.strokeRect(brX - hSize / 2, brY - hSize / 2, hSize, hSize);
      }
      ctx.restore();
    }

    drawRoundedRect(ctx, x, y, width, height, radius) {
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height - radius);
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
      ctx.lineTo(x + radius, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    }

    exportDataUrl(format = 'image/png', quality = 0.95) {
      this.render(true);
      const dataUrl = this.canvas.toDataURL(format, quality);
      this.resizeCanvas();
      this.requestRender();
      return dataUrl;
    }
  }

  // ==========================================
  // 5. TRUE GENERATIVE AI STUDIO & SMART NLP ENGINE
  // ==========================================
  class SmartAiEngine {
    constructor() {
      this.apiKey = localStorage.getItem('layer_lab_gemini_key') || '';
    }

    setApiKey(key) {
      this.apiKey = key;
      localStorage.setItem('layer_lab_gemini_key', key);
    }

    async generateFromPrompt(rawPrompt, scope = 'product-only', currentBrandState, currentProductState) {
      const prompt = (rawPrompt || '').trim();
      if (!prompt) return null;

      // If user has saved a Gemini API Key, try cloud API first
      if (this.apiKey) {
        try {
          const cloudResult = await this.callGeminiAPI(prompt, scope);
          if (cloudResult) return cloudResult;
        } catch (e) {
          console.warn('Gemini cloud call failed, using intelligent offline parser', e);
        }
      }

      // Built-in Intelligent Generative Engine
      return this.generateLocally(prompt, scope, currentBrandState);
    }

    generateLocally(prompt, scope, currentBrandState) {
      const lower = prompt.toLowerCase();

      // 1. Color Extraction
      let primaryColor = '#38bdf8'; // Default electric cyan
      let accentColor = '#fbbf24';  // Default gold

      if (lower.includes('red') || lower.includes('crimson') || lower.includes('ruby')) {
        primaryColor = '#ef4444';
        accentColor = '#18181b';
      } else if (lower.includes('blue') || lower.includes('cyan') || lower.includes('neon') || lower.includes('electric')) {
        primaryColor = '#0284c7';
        accentColor = '#38bdf8';
      } else if (lower.includes('gold') || lower.includes('yellow') || lower.includes('champagne')) {
        primaryColor = '#fbbf24';
        accentColor = '#d97706';
      } else if (lower.includes('green') || lower.includes('emerald') || lower.includes('botanical') || lower.includes('sage')) {
        primaryColor = '#10b981';
        accentColor = '#065f46';
      } else if (lower.includes('purple') || lower.includes('violet') || lower.includes('lavender')) {
        primaryColor = '#8b5cf6';
        accentColor = '#4c1d95';
      } else if (lower.includes('pink') || lower.includes('rose') || lower.includes('blush') || lower.includes('pastel')) {
        primaryColor = '#f43f5e';
        accentColor = '#fbbf24';
      } else if (lower.includes('orange') || lower.includes('terracotta') || lower.includes('amber')) {
        primaryColor = '#ea580c';
        accentColor = '#7c2d12';
      } else if (lower.includes('black') || lower.includes('dark') || lower.includes('obsidian')) {
        primaryColor = '#18181b';
        accentColor = '#e2e8f0';
      }

      // 2. Category Detection & Visual Asset Generation
      let svgContent = '';
      let defaultName = 'Artisan Product';
      let defaultPrice = '$49.00';
      let defaultDesc = 'Handcrafted premium quality with signature aesthetic finish';
      let category = 'Lifestyle';
      let themeIndex = 0;

      if (lower.includes('shoe') || lower.includes('sneaker') || lower.includes('kicks') || lower.includes('footwear') || lower.includes('runner') || lower.includes('boot')) {
        svgContent = generateSneakerSvg(primaryColor, accentColor);
        defaultName = 'Air Pulse Sport Sneaker';
        defaultPrice = '$89.00';
        defaultDesc = 'Ultra-responsive cushioning with breathable mesh and grip sole';
        category = 'Footwear & Streetwear';
        themeIndex = 2; // Tech / Urban
      } else if (lower.includes('watch') || lower.includes('chronometer') || lower.includes('timepiece') || lower.includes('rolex') || lower.includes('dial')) {
        svgContent = generateWatchSvg(accentColor || '#fbbf24', '#0f172a');
        defaultName = 'Chronos Master Chronometer';
        defaultPrice = '$299.00';
        defaultDesc = 'Swiss automatic movement with scratch-resistant sapphire crystal';
        category = 'Luxury & Horology';
        themeIndex = 0; // Luxury
      } else if (lower.includes('perfume') || lower.includes('fragrance') || lower.includes('cologne') || lower.includes('scent') || lower.includes('parfum')) {
        svgContent = generatePerfumeSvg(primaryColor, accentColor);
        defaultName = 'Velvet Orchid Eau De Parfum';
        defaultPrice = '$58.00';
        defaultDesc = 'Rich notes of bourbon vanilla, sensual amber & fresh bergamot';
        category = 'Fragrance & Beauty';
        themeIndex = 0; // Luxury
      } else if (lower.includes('candle') || lower.includes('wax') || lower.includes('aroma') || lower.includes('wick')) {
        svgContent = generateCandleSvg('#fed7aa', primaryColor);
        defaultName = 'Nordic Amber Soy Candle';
        defaultPrice = '$28.00';
        defaultDesc = 'Hand-poured coconut soy wax with natural crackling wooden wick';
        category = 'Home & Aromatherapy';
        themeIndex = 4; // Artisan
      } else if (lower.includes('headphone') || lower.includes('audio') || lower.includes('sound') || lower.includes('earbud') || lower.includes('speaker') || lower.includes('wireless') || lower.includes('anc')) {
        svgContent = SAMPLE_PRODUCTS[2].svg;
        defaultName = 'AeroTune Pro ANC Wireless';
        defaultPrice = '$149.00';
        defaultDesc = 'Hi-Res Spatial Audio with 40-hour battery and smart active noise cancel';
        category = 'Audio & Electronics';
        themeIndex = 2; // Tech
      } else if (lower.includes('serum') || lower.includes('skin') || lower.includes('botanical') || lower.includes('cream') || lower.includes('lotion') || lower.includes('face') || lower.includes('elixir') || lower.includes('glow')) {
        svgContent = SAMPLE_PRODUCTS[3].svg;
        defaultName = 'Glow Botanical Face Elixir';
        defaultPrice = '$42.00';
        defaultDesc = 'Cold-pressed Rosehip & Vitamin C for luminous skin barrier repair';
        category = 'Skincare & Clean Beauty';
        themeIndex = 3; // Botanical
      } else if (lower.includes('coffee') || lower.includes('bean') || lower.includes('roast') || lower.includes('cafe') || lower.includes('espresso') || lower.includes('brew') || lower.includes('tea')) {
        svgContent = SAMPLE_PRODUCTS[1].svg;
        defaultName = 'Highland Reserve Coffee Roast';
        defaultPrice = '$22.00';
        defaultDesc = 'Washed single-origin beans with tasting notes of honey, citrus & cocoa';
        category = 'Specialty Coffee';
        themeIndex = 1; // Nordic
      } else if (lower.includes('mug') || lower.includes('ceramic') || lower.includes('pottery') || lower.includes('clay') || lower.includes('stoneware') || lower.includes('handcrafted')) {
        svgContent = SAMPLE_PRODUCTS[4].svg;
        defaultName = 'Wabi-Sabi Speckled Mug';
        defaultPrice = '$34.00';
        defaultDesc = 'Wheel-thrown artisanal stoneware with toasted iron-fleck glaze';
        category = 'Ceramics & Tableware';
        themeIndex = 4; // Earth & Clay
      } else if (lower.includes('bag') || lower.includes('leather') || lower.includes('purse') || lower.includes('tote') || lower.includes('crossbody') || lower.includes('backpack')) {
        svgContent = SAMPLE_PRODUCTS[0].svg;
        defaultName = 'Verona Pebble Leather Tote';
        defaultPrice = '$135.00';
        defaultDesc = 'Full-grain Italian calfskin with brushed gold hardware and zip closure';
        category = 'Leather & Fashion';
        themeIndex = 0; // Luxury
      } else {
        // Universal generative product display for ANY custom request!
        defaultName = this.extractTitle(prompt) || 'Custom Designer Edition';
        svgContent = generateUniversalProductSvg(defaultName, primaryColor);
        defaultPrice = '$49.00';
        defaultDesc = 'Crafted with premium materials and signature artisan design';
        category = 'Signature Edition';
        themeIndex = 0;
      }

      // 3. Price & Strike Price Extraction
      let price = defaultPrice;
      let originalPrice = '';

      // Check for price with dollar sign
      const priceRegex = /\$\s*([0-9]+(?:\.[0-9]{2})?)/g;
      const dollarMatches = prompt.match(priceRegex);

      if (dollarMatches && dollarMatches.length > 0) {
        price = dollarMatches[0].replace(/\s+/g, '');
        if (dollarMatches.length > 1) {
          originalPrice = dollarMatches[1].replace(/\s+/g, '');
        }
      } else {
        // Check for words like "price 80" or "80 dollars" or "80 bucks"
        const numMatch = prompt.match(/(?:price|cost|for|only)?\s*([0-9]{1,4})\s*(?:dollars|bucks|usd|\$)/i) || prompt.match(/price\s*(?:is|of|:)?\s*([0-9]{1,4})/i);
        if (numMatch && numMatch[1]) {
          price = `$${parseInt(numMatch[1], 10)}.00`;
        }
      }

      // Check for strike price ("was 120" or "originally 150")
      const wasMatch = prompt.match(/(?:was|originally|before|from)\s*\$?([0-9]+(?:\.[0-9]{2})?)/i);
      if (wasMatch && wasMatch[1]) {
        originalPrice = `$${parseFloat(wasMatch[1]).toFixed(2)}`;
      }

      // 4. Promotional Badge Extraction
      let badge = 'NEW ARRIVAL';
      const discountMatch = prompt.match(/([0-9]{1,2}%\s*off)/i) || prompt.match(/([0-9]{1,2}%)\s*discount/i);

      if (discountMatch) {
        badge = discountMatch[1].toUpperCase();
        // If discount is given but no strike price was mentioned, compute strike price!
        if (!originalPrice && price) {
          const priceNum = parseFloat(price.replace('$', ''));
          const pct = parseInt(discountMatch[1], 10);
          if (priceNum > 0 && pct > 0 && pct < 90) {
            originalPrice = `$${(priceNum / (1 - pct / 100)).toFixed(2)}`;
          }
        }
      } else if (lower.includes('flash sale')) {
        badge = 'FLASH SALE';
      } else if (lower.includes('limited')) {
        badge = 'LIMITED EDITION';
      } else if (lower.includes('best seller') || lower.includes('bestseller')) {
        badge = 'BEST SELLER';
      } else if (lower.includes('organic')) {
        badge = '100% ORGANIC';
      } else if (lower.includes('handmade') || lower.includes('handcrafted')) {
        badge = 'HANDCRAFTED';
      } else if (lower.includes('bogo') || lower.includes('buy 1 get 1')) {
        badge = 'BUY 1 GET 1';
      } else if (lower.includes('hot deal') || lower.includes('deal')) {
        badge = 'HOT DEAL';
      }

      // 5. Product Title Extraction
      const extractedTitle = this.extractTitle(prompt);
      const name = extractedTitle || defaultName;

      // 6. Assemble Product Layer
      const generatedProduct = {
        name,
        price,
        originalPrice,
        badge,
        badgeColor: primaryColor,
        description: defaultDesc,
        svgDataUrl: svgToDataUrl(svgContent),
        imageUrl: null,
        scale: 0.95,
        posX: 0,
        posY: 10
      };

      // 7. Assemble Brand Layer if scope is 'full-creative'
      let generatedBrand = null;
      if (scope === 'full-creative') {
        const baseTemplate = BRAND_TEMPLATES[themeIndex] || BRAND_TEMPLATES[0];
        generatedBrand = JSON.parse(JSON.stringify(baseTemplate.brand));
        generatedBrand.accentColor = accentColor;
        generatedBrand.badgeBgColor = primaryColor;

        if (lower.includes('sneaker') || lower.includes('shoe')) {
          generatedBrand.name = 'KINETIC KICKS LAB';
          generatedBrand.tagline = 'STREETWEAR & ATHLETIC PERFORMANCE';
        } else if (lower.includes('watch')) {
          generatedBrand.name = 'CHRONOS HAUTE HORLOGERIE';
          generatedBrand.tagline = 'GENÈVE • TIMELESS PRECISION';
        } else if (lower.includes('perfume')) {
          generatedBrand.name = 'MAISON DE FLEUR';
          generatedBrand.tagline = 'HAUTE PARFUMERIE • PARIS';
        } else if (lower.includes('candle')) {
          generatedBrand.name = 'LUMIÈRE ATELIER';
          generatedBrand.tagline = 'BOTANICAL SOY APOTHECARY';
        }
      }

      return {
        product: generatedProduct,
        brand: generatedBrand,
        summary: `✨ Created "${name}" (${price}) with badge [${badge}]`
      };
    }

    extractTitle(prompt) {
      if (!prompt) return '';

      // Strip common conversational / command fluff
      let clean = prompt
        .replace(/(?:can\s+you\s+)?(?:create|make|generate|design|i\s+need|i\s+want|give\s+me|please)\s+(?:a|an|the)?/gi, '')
        .replace(/product\s+(?:for|of)?/gi, '')
        .replace(/(?:sale|banner|creative|post|ad)\s+for/gi, '')
        .replace(/\$\s*[0-9]+(?:\.[0-9]{2})?/g, '')
        .replace(/[0-9]{1,4}\s*(?:dollars|bucks|usd)/gi, '')
        .replace(/(?:was|originally)\s*\$?[0-9.]+/gi, '')
        .replace(/[0-9]{1,2}%\s*off/gi, '')
        .replace(/(?:flash\s+sale|limited\s+edition|best\s+seller|new\s+arrival)/gi, '')
        .replace(/with\s+(?:badge|price|discount|theme|aesthetic|vibe).*/gi, '')
        .replace(/[,.!?]/g, '')
        .trim();

      const words = clean.split(/\s+/).filter(w => w.length > 1 && !['with', 'for', 'and', 'the', 'price', 'badge'].includes(w.toLowerCase()));

      if (words.length >= 2) {
        return words.slice(0, 4).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
      } else if (words.length === 1) {
        return words[0].charAt(0).toUpperCase() + words[0].slice(1).toLowerCase() + ' Edition';
      }

      return '';
    }

    async callGeminiAPI(userPrompt, scope) {
      const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.apiKey}`;
      const systemInstruction = `You are an AI graphic design assistant for Layer Lab. Given a user prompt for a product creative, output ONLY a valid JSON object matching this structure:
      {
        "name": "Product Title",
        "price": "$XX.XX",
        "originalPrice": "$XX.XX",
        "badge": "DISCOUNT OR BADGE",
        "description": "Short 1-line feature description",
        "category": "sneaker" or "watch" or "perfume" or "candle" or "coffee" or "headphones" or "serum" or "ceramic" or "handbag" or "universal"
      }`;

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: `${systemInstruction}\n\nUser Request: ${userPrompt}` }]
          }]
        })
      });

      if (!response.ok) return null;
      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text) return null;

      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) return null;
      const parsed = JSON.parse(jsonMatch[0]);

      let svg = '';
      if (parsed.category === 'sneaker') svg = generateSneakerSvg('#ef4444', '#18181b');
      else if (parsed.category === 'watch') svg = generateWatchSvg('#fbbf24', '#0f172a');
      else if (parsed.category === 'perfume') svg = generatePerfumeSvg('#f43f5e', '#fbbf24');
      else if (parsed.category === 'candle') svg = generateCandleSvg('#fed7aa', '#d97706');
      else if (parsed.category === 'coffee') svg = SAMPLE_PRODUCTS[1].svg;
      else if (parsed.category === 'headphones') svg = SAMPLE_PRODUCTS[2].svg;
      else if (parsed.category === 'serum') svg = SAMPLE_PRODUCTS[3].svg;
      else if (parsed.category === 'ceramic') svg = SAMPLE_PRODUCTS[4].svg;
      else if (parsed.category === 'handbag') svg = SAMPLE_PRODUCTS[0].svg;
      else svg = generateUniversalProductSvg(parsed.name, '#8b5cf6');

      return {
        product: {
          name: parsed.name,
          price: parsed.price || '$49.00',
          originalPrice: parsed.originalPrice || '',
          badge: parsed.badge || 'NEW ARRIVAL',
          badgeColor: '#38bdf8',
          description: parsed.description || 'Premium craftsmanship and signature design',
          svgDataUrl: svgToDataUrl(svg),
          imageUrl: null,
          scale: 0.95,
          posX: 0,
          posY: 10
        },
        brand: null,
        summary: `AI Generated: ${parsed.name}`
      };
    }
  }

  // ==========================================
  // 6. APPLICATION CONTROLLER
  // ==========================================
  class LayerLabApp {
    constructor() {
      this.currentTemplateIndex = 0;
      this.currentTemplate = BRAND_TEMPLATES[0];

      this.brandState = JSON.parse(JSON.stringify(this.currentTemplate.brand));
      this.productState = JSON.parse(JSON.stringify(this.currentTemplate.defaultProduct));

      const initialSample = SAMPLE_PRODUCTS.find(p => p.id === this.productState.sampleId) || SAMPLE_PRODUCTS[0];
      this.productState.svgDataUrl = svgToDataUrl(initialSample.svg);
      this.productState.name = initialSample.name;
      this.productState.price = initialSample.price;
      this.productState.originalPrice = initialSample.originalPrice;
      this.productState.badge = initialSample.badge;
      this.productState.description = initialSample.description;

      this.isBrandModeUnlocked = false;
      this.currentAspectRatio = '1:1';

      this.aiEngine = new SmartAiEngine();

      this.initHistory();
      this.initCanvas();
      this.initDOM();
      this.bindEvents();

      this.syncFormFields();
      this.updateModeUI();
      this.canvasEngine.requestRender();
      this.showToast('Layer Lab Ready: AI Studio & Brand Protected 🔒', 'success');
    }

    initHistory() {
      this.history = new HistoryManager({
        onHistoryChange: (status) => this.updateHistoryUI(status),
        onToast: (msg, type) => this.showToast(msg, type)
      });
      this.history.pushBrandState('Initial Brand Setup', this.brandState);
      this.history.pushProductState('Initial Product Setup', this.productState);
    }

    initCanvas() {
      const canvas = document.getElementById('mainCanvas');
      this.canvasEngine = new CanvasEngine(canvas, {
        onStateModified: (label) => {
          this.history.pushProductState(label, this.productState);
          this.syncFormFields();
        }
      });
      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
    }

    initDOM() {
      const templateSelect = document.getElementById('templateSelect');
      templateSelect.innerHTML = BRAND_TEMPLATES.map((t, idx) =>
        `<option value="${idx}">${t.name} (${t.category})</option>`
      ).join('');

      const sampleGrid = document.getElementById('sampleProductGrid');
      sampleGrid.innerHTML = SAMPLE_PRODUCTS.map((prod) => `
        <button data-prod-id="${prod.id}" class="sample-prod-btn p-1.5 rounded-xl border border-white/10 hover:border-cyan-400 bg-slate-900/60 hover:bg-slate-800 transition-all flex flex-col items-center group" title="${prod.name} (${prod.category})">
          <div class="w-12 h-12 flex items-center justify-center p-0.5 rounded-lg bg-black/40 group-hover:scale-105 transition-transform">
            <img src="${svgToDataUrl(prod.svg)}" alt="${prod.name}" class="w-11 h-11 object-contain pointer-events-none">
          </div>
          <span class="text-[9px] text-slate-300 font-medium truncate w-full text-center mt-1 group-hover:text-cyan-300">${prod.name.split(' ')[0]}</span>
        </button>
      `).join('');

      const savedKey = localStorage.getItem('layer_lab_gemini_key');
      if (savedKey) {
        const inputApiKey = document.getElementById('inputApiKey');
        if (inputApiKey) inputApiKey.value = savedKey;
      }
    }

    bindEvents() {
      // 1. 4-Tab Navigation
      const tabs = [
        { btn: document.getElementById('tabAI'), panel: document.getElementById('panelAI'), isAI: true },
        { btn: document.getElementById('tabProducts'), panel: document.getElementById('panelProducts') },
        { btn: document.getElementById('tabBrand'), panel: document.getElementById('panelBrand') },
        { btn: document.getElementById('tabHistory'), panel: document.getElementById('panelHistory') }
      ];

      tabs.forEach(({ btn, panel, isAI }) => {
        btn.addEventListener('click', () => {
          tabs.forEach(t => {
            t.btn.classList.remove('active', 'text-cyan-400', 'bg-cyan-500/10', 'tab-btn-ai');
            t.btn.classList.add('text-slate-400');
            t.panel.classList.add('hidden');
          });

          if (isAI) {
            btn.classList.add('active', 'tab-btn-ai');
          } else {
            btn.classList.add('active', 'text-cyan-400', 'bg-cyan-500/10');
          }
          btn.classList.remove('text-slate-400');
          panel.classList.remove('hidden');
        });
      });

      // 2. AI Prompt Generation & Inspiration Chips
      const aiPromptInput = document.getElementById('aiPromptInput');
      const btnAiGenerate = document.getElementById('btnAiGenerate');
      const btnClearPrompt = document.getElementById('btnClearPrompt');

      btnClearPrompt.addEventListener('click', () => {
        aiPromptInput.value = '';
        aiPromptInput.focus();
      });

      document.querySelectorAll('.ai-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          const promptText = chip.getAttribute('data-prompt');
          aiPromptInput.value = promptText;
          aiPromptInput.focus();
          this.triggerAiGeneration();
        });
      });

      btnAiGenerate.addEventListener('click', () => {
        this.triggerAiGeneration();
      });

      // AI Scope Radio Hint
      document.querySelectorAll('input[name="aiScope"]').forEach(radio => {
        radio.addEventListener('change', () => {
          const hint = document.getElementById('aiScopeHint');
          if (radio.value === 'product-only') {
            hint.textContent = '✓ AI only updates product copy & visuals. Your master brand layout is preserved!';
            hint.className = 'text-[10px] text-emerald-400/90 leading-tight';
          } else {
            hint.textContent = '🎨 AI will craft a brand new brand aesthetic and matching product creative.';
            hint.className = 'text-[10px] text-purple-400/90 leading-tight';
          }
        });
      });

      // API Key Save
      document.getElementById('btnSaveApiKey').addEventListener('click', () => {
        const val = document.getElementById('inputApiKey').value.trim();
        this.aiEngine.setApiKey(val);
        this.showToast(val ? 'Gemini API Key Saved!' : 'Cleared API Key (Using offline AI)', 'success');
      });

      // 3. Brand Master Lock / Unlock Toggle
      const modeToggleBtn = document.getElementById('modeToggleBtn');
      const brandLockCheckbox = document.getElementById('brandLockCheckbox');

      const toggleLockMode = () => {
        this.isBrandModeUnlocked = !this.isBrandModeUnlocked;
        brandLockCheckbox.checked = !this.isBrandModeUnlocked;
        this.updateModeUI();
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);

        if (this.isBrandModeUnlocked) {
          this.showToast('Brand Mode Unlocked 🔓 (Editing Master Theme)', 'warning');
        } else {
          this.showToast('Brand Protected 🔒 (Product Edits Only)', 'success');
        }
      };

      modeToggleBtn.addEventListener('click', toggleLockMode);
      brandLockCheckbox.addEventListener('change', () => {
        this.isBrandModeUnlocked = !brandLockCheckbox.checked;
        this.updateModeUI();
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });

      // 4. Scoped Undo / Redo Controls
      const btnUndo = document.getElementById('btnUndo');
      const btnRedo = document.getElementById('btnRedo');

      btnUndo.addEventListener('click', () => this.handleUndo());
      btnRedo.addEventListener('click', () => this.handleRedo());

      window.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;

        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
          if (e.shiftKey) this.handleRedo();
          else this.handleUndo();
          e.preventDefault();
        } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
          this.handleRedo();
          e.preventDefault();
        }
      });

      // 5. Sample Product Click
      document.querySelectorAll('.sample-prod-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const prodId = btn.getAttribute('data-prod-id');
          this.applySampleProduct(prodId);
        });
      });

      // Custom Image Upload
      const imageUploadInput = document.getElementById('imageUploadInput');
      imageUploadInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
          this.productState.imageUrl = event.target.result;
          this.productState.svgDataUrl = null;
          this.productState.scale = 1.0;
          this.productState.posX = 0;
          this.productState.posY = 0;
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
          this.history.pushProductState('Uploaded Custom Product Photo', this.productState);
          this.syncFormFields();
          this.showToast('Custom product photo loaded!', 'success');
        };
        reader.readAsDataURL(file);
      });

      document.getElementById('btnResetProductPos').addEventListener('click', () => {
        this.productState.posX = 0;
        this.productState.posY = 0;
        this.productState.scale = 1.0;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        this.history.pushProductState('Centered Product Position', this.productState);
        this.syncFormFields();
        this.showToast('Product centered', 'info');
      });

      // 6. Product Form Bindings
      const bindProductInput = (elementId, stateKey, label) => {
        const el = document.getElementById(elementId);
        if (!el) return;
        el.addEventListener('input', () => {
          this.productState[stateKey] = el.value;
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        });
        el.addEventListener('change', () => {
          this.history.pushProductState(`Changed ${label} to "${el.value}"`, this.productState);
        });
      };

      bindProductInput('inputProdTitle', 'name', 'Product Title');
      bindProductInput('inputProdDesc', 'description', 'Description');
      bindProductInput('inputProdPrice', 'price', 'Display Price');
      bindProductInput('inputProdOriginalPrice', 'originalPrice', 'Original Price');
      bindProductInput('inputProdBadge', 'badge', 'Promotional Badge');

      document.querySelectorAll('.quick-badge').forEach(badgeBtn => {
        badgeBtn.addEventListener('click', () => {
          const text = badgeBtn.textContent;
          this.productState.badge = text;
          document.getElementById('inputProdBadge').value = text;
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
          this.history.pushProductState(`Set Badge to "${text}"`, this.productState);
        });
      });

      const inputProdScale = document.getElementById('inputProdScale');
      const scaleDisplay = document.getElementById('scaleDisplay');
      inputProdScale.addEventListener('input', () => {
        const scaleVal = parseFloat(inputProdScale.value) / 100;
        this.productState.scale = scaleVal;
        scaleDisplay.textContent = `${inputProdScale.value}%`;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputProdScale.addEventListener('change', () => {
        this.history.pushProductState(`Resized Product to ${inputProdScale.value}%`, this.productState);
      });

      // 7. Master Brand Form Inputs (Protected if Locked!)
      const bindBrandInput = (elementId, stateKey, label) => {
        const el = document.getElementById(elementId);
        if (!el) return;
        el.addEventListener('input', () => {
          if (!this.isBrandModeUnlocked) {
            this.showToast('Unlock Brand Mode to edit brand styling', 'warning');
            this.syncFormFields();
            return;
          }
          this.brandState[stateKey] = el.value;
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        });
        el.addEventListener('change', () => {
          if (!this.isBrandModeUnlocked) return;
          this.history.pushBrandState(`Updated Brand ${label}`, this.brandState);
        });
      };

      bindBrandInput('inputBrandName', 'name', 'Name');
      bindBrandInput('inputBrandTagline', 'tagline', 'Tagline');
      bindBrandInput('inputBrandHandle', 'handle', 'Handle');
      bindBrandInput('inputBrandLogo', 'logoMonogram', 'Logo Monogram');
      bindBrandInput('selectFrameStyle', 'frameStyle', 'Frame Style');

      const inputAccentColor = document.getElementById('inputAccentColor');
      const accentHexDisplay = document.getElementById('accentHexDisplay');
      inputAccentColor.addEventListener('input', () => {
        if (!this.isBrandModeUnlocked) {
          this.showToast('Unlock Brand Mode to change colors', 'warning');
          inputAccentColor.value = this.brandState.accentColor;
          return;
        }
        this.brandState.accentColor = inputAccentColor.value;
        accentHexDisplay.textContent = inputAccentColor.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputAccentColor.addEventListener('change', () => {
        if (!this.isBrandModeUnlocked) return;
        this.history.pushBrandState('Changed Accent Color', this.brandState);
      });

      const inputTextColor = document.getElementById('inputTextColor');
      const textHexDisplay = document.getElementById('textHexDisplay');
      inputTextColor.addEventListener('input', () => {
        if (!this.isBrandModeUnlocked) {
          this.showToast('Unlock Brand Mode to change text color', 'warning');
          inputTextColor.value = this.brandState.textColor;
          return;
        }
        this.brandState.textColor = inputTextColor.value;
        textHexDisplay.textContent = inputTextColor.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputTextColor.addEventListener('change', () => {
        if (!this.isBrandModeUnlocked) return;
        this.history.pushBrandState('Changed Text Color', this.brandState);
      });

      const templateSelect = document.getElementById('templateSelect');
      templateSelect.addEventListener('change', () => {
        const idx = parseInt(templateSelect.value, 10);
        this.applyTemplate(idx);
      });

      document.querySelectorAll('.ratio-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('.ratio-btn').forEach(b => {
            b.classList.remove('active', 'bg-cyan-600', 'text-white', 'font-semibold');
            b.classList.add('text-slate-400');
          });
          btn.classList.add('active', 'bg-cyan-600', 'text-white', 'font-semibold');
          btn.classList.remove('text-slate-400');
          const ratio = btn.getAttribute('data-ratio');
          this.setAspectRatio(ratio);
        });
      });

      document.getElementById('btnDownloadPng').addEventListener('click', () => this.exportImage('png'));
      document.getElementById('btnDownloadJpg').addEventListener('click', () => this.exportImage('jpeg'));
      document.getElementById('btnCopyClipboard').addEventListener('click', () => this.copyToClipboard());
    }

    async triggerAiGeneration() {
      const promptInput = document.getElementById('aiPromptInput');
      const prompt = promptInput.value.trim();

      if (!prompt) {
        this.showToast('Please type a prompt first or click an inspiration chip!', 'warning');
        promptInput.focus();
        return;
      }

      const selectedScope = document.querySelector('input[name="aiScope"]:checked')?.value || 'product-only';

      // UI Loading state
      const btn = document.getElementById('btnAiGenerate');
      const spinner = document.getElementById('aiBtnSpinner');
      const icon = document.getElementById('aiBtnIcon');
      const text = document.getElementById('aiBtnText');

      btn.disabled = true;
      spinner.classList.remove('hidden');
      icon.classList.add('hidden');
      text.textContent = 'AI is styling your creative...';

      try {
        await new Promise(r => setTimeout(r, 600));

        const result = await this.aiEngine.generateFromPrompt(prompt, selectedScope, this.brandState, this.productState);

        if (result && result.product) {
          // Clear previous uploaded photo to show new AI vector
          this.productState = {
            ...this.productState,
            ...result.product,
            imageUrl: null
          };

          // If full-creative mode and brand was returned
          if (selectedScope === 'full-creative' && result.brand) {
            this.brandState = {
              ...this.brandState,
              ...result.brand
            };
            this.history.pushBrandState(`AI Created Brand: ${result.brand.name}`, this.brandState);
          }

          // Push to history so user can Undo!
          this.history.pushProductState(`AI Generated: ${result.product.name}`, this.productState);

          // Force canvas re-render and UI sync
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
          this.canvasEngine.requestRender();
          this.syncFormFields();

          // Update AI Result Card
          const resultCard = document.getElementById('aiResultCard');
          const resultName = document.getElementById('aiResultName');
          const resultPrice = document.getElementById('aiResultPrice');
          const resultBadge = document.getElementById('aiResultBadge');
          const resultDesc = document.getElementById('aiResultDesc');

          if (resultCard) {
            resultCard.classList.remove('hidden');
            resultName.textContent = result.product.name;
            resultPrice.textContent = result.product.originalPrice ? `${result.product.price} (Was ${result.product.originalPrice})` : result.product.price;
            resultBadge.textContent = result.product.badge;
            resultDesc.textContent = result.product.description;
          }

          this.showToast(`✨ AI Generated: ${result.product.name} (Live on Canvas!)`, 'success');
        }
      } catch (err) {
        console.error('AI generation error:', err);
        this.showToast('AI generation encountered an error', 'warning');
      } finally {
        btn.disabled = false;
        spinner.classList.add('hidden');
        icon.classList.remove('hidden');
        text.textContent = 'Generate Creative with AI';
      }
    }

    handleUndo() {
      const result = this.history.undo(this.isBrandModeUnlocked, this.productState, this.brandState);
      if (!result) return;
      if (result.type === 'product') this.productState = result.state;
      else if (result.type === 'brand') this.brandState = result.state;

      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      this.syncFormFields();
    }

    handleRedo() {
      const result = this.history.redo(this.isBrandModeUnlocked);
      if (!result) return;
      if (result.type === 'product') this.productState = result.state;
      else if (result.type === 'brand') this.brandState = result.state;

      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      this.syncFormFields();
    }

    applySampleProduct(prodId) {
      const prod = SAMPLE_PRODUCTS.find(p => p.id === prodId);
      if (!prod) return;

      this.productState.name = prod.name;
      this.productState.price = prod.price;
      this.productState.originalPrice = prod.originalPrice;
      this.productState.badge = prod.badge;
      this.productState.badgeColor = prod.badgeColor;
      this.productState.description = prod.description;
      this.productState.svgDataUrl = svgToDataUrl(prod.svg);
      this.productState.imageUrl = null;
      this.productState.posX = 0;
      this.productState.posY = 10;
      this.productState.scale = 0.95;

      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      this.history.pushProductState(`Swapped to ${prod.name}`, this.productState);
      this.syncFormFields();
      this.showToast(`Swapped to ${prod.name} (Brand layout preserved 🛡️)`, 'success');
    }

    applyTemplate(index) {
      const t = BRAND_TEMPLATES[index];
      if (!t) return;

      this.currentTemplateIndex = index;
      this.currentTemplate = t;
      this.brandState = JSON.parse(JSON.stringify(t.brand));

      const sample = SAMPLE_PRODUCTS.find(p => p.id === t.defaultProduct.sampleId) || SAMPLE_PRODUCTS[0];
      this.productState = {
        ...JSON.parse(JSON.stringify(t.defaultProduct)),
        svgDataUrl: svgToDataUrl(sample.svg),
        imageUrl: null
      };

      this.history.pushBrandState(`Switched Theme to ${t.name}`, this.brandState);
      this.history.pushProductState(`Loaded ${t.name} Product Preset`, this.productState);
      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      this.syncFormFields();
      this.showToast(`Applied Theme: ${t.name}`, 'info');
    }

    setAspectRatio(ratio) {
      this.currentAspectRatio = ratio;
      const canvas = document.getElementById('mainCanvas');
      canvas.classList.remove('aspect-square', 'aspect-[9/16]', 'aspect-video');

      if (ratio === '1:1') {
        canvas.classList.add('aspect-square');
        this.canvasEngine.setDimensions(1080, 1080);
      } else if (ratio === '9:16') {
        canvas.classList.add('aspect-[9/16]');
        this.canvasEngine.setDimensions(1080, 1920);
      } else if (ratio === '16:9') {
        canvas.classList.add('aspect-video');
        this.canvasEngine.setDimensions(1920, 1080);
      }
      this.showToast(`Canvas Format: ${ratio}`, 'info');
    }

    updateModeUI() {
      const modeToggleBtn = document.getElementById('modeToggleBtn');
      const modeLockIcon = document.getElementById('modeLockIcon');
      const modeStatusLabel = document.getElementById('modeStatusLabel');
      const brandLockCardIcon = document.getElementById('brandLockCardIcon');
      const lockStatusMessage = document.getElementById('lockStatusMessage');
      const brandLockCheckbox = document.getElementById('brandLockCheckbox');

      if (this.isBrandModeUnlocked) {
        modeToggleBtn.classList.remove('bg-emerald-500/10', 'border-emerald-500/30', 'text-emerald-400', 'brand-locked-pulse');
        modeToggleBtn.classList.add('bg-amber-500/10', 'border-amber-500/40', 'text-amber-400');
        modeLockIcon.textContent = '🔓';
        modeStatusLabel.textContent = 'BRAND DESIGN MODE (Unlocked)';
        brandLockCardIcon.textContent = '🔓';
        lockStatusMessage.textContent = '⚠️ Master Brand is unlocked. Edits here change the template aesthetic.';
        lockStatusMessage.className = 'text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20';
        brandLockCheckbox.checked = false;
      } else {
        modeToggleBtn.classList.remove('bg-amber-500/10', 'border-amber-500/40', 'text-amber-400');
        modeToggleBtn.classList.add('bg-emerald-500/10', 'border-emerald-500/30', 'text-emerald-400', 'brand-locked-pulse');
        modeLockIcon.textContent = '🔒';
        modeStatusLabel.textContent = 'BRAND LOCKED (Safe Mode)';
        brandLockCardIcon.textContent = '🔒';
        lockStatusMessage.textContent = '✓ Brand layout is securely frozen. All product updates and undos are safe.';
        lockStatusMessage.className = 'text-[11px] text-emerald-400 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20';
        brandLockCheckbox.checked = true;
      }
    }

    updateHistoryUI(status) {
      const btnUndo = document.getElementById('btnUndo');
      const btnRedo = document.getElementById('btnRedo');

      const canUndo = this.history.canUndo(this.isBrandModeUnlocked);
      const canRedo = this.history.canRedo(this.isBrandModeUnlocked);

      btnUndo.disabled = !canUndo;
      btnRedo.disabled = !canRedo;

      const listContainer = document.getElementById('historyListContainer');
      const historyCount = document.getElementById('historyActionCount');
      const logs = this.history.getHistoryLogs(this.isBrandModeUnlocked);

      historyCount.textContent = `${logs.length} step${logs.length === 1 ? '' : 's'}`;

      listContainer.innerHTML = logs.map(item => `
        <div class="p-2.5 rounded-lg border ${item.isCurrent ? 'bg-cyan-500/10 border-cyan-500/40' : 'bg-slate-900/60 border-white/5'} flex items-center justify-between text-xs">
          <div class="flex items-center space-x-2">
            <span class="${item.isCurrent ? 'text-cyan-400 font-bold' : 'text-slate-500'} font-mono text-[10px]">#${item.index + 1}</span>
            <span class="${item.isCurrent ? 'text-white font-semibold' : 'text-slate-300'}">${item.label}</span>
          </div>
          <span class="text-[10px] text-slate-500">${item.time}</span>
        </div>
      `).join('');
    }

    syncFormFields() {
      document.getElementById('inputProdTitle').value = this.productState.name || '';
      document.getElementById('inputProdDesc').value = this.productState.description || '';
      document.getElementById('inputProdPrice').value = this.productState.price || '';
      document.getElementById('inputProdOriginalPrice').value = this.productState.originalPrice || '';
      document.getElementById('inputProdBadge').value = this.productState.badge || '';

      const scaleVal = Math.round((this.productState.scale || 1.0) * 100);
      document.getElementById('inputProdScale').value = scaleVal;
      document.getElementById('scaleDisplay').textContent = `${scaleVal}%`;

      document.getElementById('inputBrandName').value = this.brandState.name || '';
      document.getElementById('inputBrandTagline').value = this.brandState.tagline || '';
      document.getElementById('inputBrandHandle').value = this.brandState.handle || '';
      document.getElementById('inputBrandLogo').value = this.brandState.logoMonogram || '';
      document.getElementById('selectFrameStyle').value = this.brandState.frameStyle || 'ornate-border';

      document.getElementById('inputAccentColor').value = this.brandState.accentColor || '#d4af37';
      document.getElementById('accentHexDisplay').textContent = this.brandState.accentColor || '#d4af37';

      document.getElementById('inputTextColor').value = this.brandState.textColor || '#ffffff';
      document.getElementById('textHexDisplay').textContent = this.brandState.textColor || '#ffffff';
    }

    exportImage(format = 'png') {
      const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
      const ext = format === 'jpeg' ? 'jpg' : 'png';
      const dataUrl = this.canvasEngine.exportDataUrl(mimeType, 0.95);

      const filename = `layer-lab-${(this.productState.name || 'product').toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}.${ext}`;

      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      this.showToast(`Exported high-res ${ext.toUpperCase()} successfully!`, 'success');
    }

    async copyToClipboard() {
      try {
        this.canvasEngine.render(true);
        const canvas = document.getElementById('mainCanvas');

        canvas.toBlob(async (blob) => {
          if (!blob) {
            this.showToast('Failed to copy canvas', 'warning');
            return;
          }
          try {
            await navigator.clipboard.write([
              new ClipboardItem({ 'image/png': blob })
            ]);
            this.showToast('Copied high-res image to clipboard!', 'success');
          } catch (err) {
            this.showToast('Clipboard access restricted in this browser context', 'info');
          } finally {
            this.canvasEngine.resizeCanvas();
            this.canvasEngine.requestRender();
          }
        }, 'image/png', 0.95);
      } catch (e) {
        this.showToast('Could not copy image to clipboard', 'warning');
      }
    }

    showToast(message, type = 'info') {
      const container = document.getElementById('toastContainer');
      if (!container) return;

      const toast = document.createElement('div');
      const colors = {
        success: 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200 shadow-emerald-900/30',
        warning: 'bg-amber-950/90 border-amber-500/50 text-amber-200 shadow-amber-900/30',
        info: 'bg-slate-900/90 border-cyan-500/40 text-cyan-200 shadow-cyan-900/30'
      };
      const icons = { success: '🛡️', warning: '⚠️', info: '✨' };

      toast.className = `flex items-center space-x-2.5 px-4 py-2.5 rounded-xl border backdrop-blur-md shadow-xl text-xs transition-all duration-300 transform translate-y-3 opacity-0 ${colors[type] || colors.info}`;
      toast.innerHTML = `
        <span class="text-sm">${icons[type] || '✨'}</span>
        <span class="font-medium">${message}</span>
      `;

      container.appendChild(toast);

      setTimeout(() => {
        toast.classList.remove('translate-y-3', 'opacity-0');
        toast.classList.add('translate-y-0', 'opacity-100');
      }, 10);

      setTimeout(() => {
        toast.classList.remove('translate-y-0', 'opacity-100');
        toast.classList.add('translate-y-3', 'opacity-0');
        setTimeout(() => toast.remove(), 350);
      }, 3200);
    }
  }

  // Launch on DOM ready
  window.addEventListener('DOMContentLoaded', () => {
    window.app = new LayerLabApp();
  });

})();
