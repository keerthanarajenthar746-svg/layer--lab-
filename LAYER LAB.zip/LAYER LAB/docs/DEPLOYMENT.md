# 🚀 Deployment Guide for Layer Lab

Layer Lab is structured with zero external server dependencies, meaning it can be deployed to any static host in under 60 seconds for free.

---

## 1. Deploying to GitHub Pages (Free)

1. Push or drag-and-drop the files from `layer-lab/` to a public repository on GitHub.
2. Navigate to your repository's **Settings** > **Pages**.
3. Under **Branch**, select `main` (or `master`) and directory `/ (root)`.
4. Click **Save**.
5. Your live URL will be ready at:
   ```text
   https://<your-username>.github.io/<repo-name>/
   ```

---

## 2. Deploying to Vercel (1-Click)

Layer Lab includes a pre-configured `vercel.json`:
1. Log in to [vercel.com](https://vercel.com).
2. Click **Add New...** > **Project**.
3. Import your GitHub repository or drag the `layer-lab` folder into the dashboard.
4. Click **Deploy**.

---

## 3. Deploying to Netlify (Drag & Drop)

Layer Lab includes a pre-configured `netlify.toml`:
1. Visit [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop the `layer-lab` folder directly into your browser window.
3. Your web app is live instantly with an SSL certificate.

---

## 4. Running Locally in VS Code

- Open the `layer-lab` folder in VS Code.
- Press **`F5`** to launch in Google Chrome or Microsoft Edge (configured via `.vscode/launch.json`).
- Or right-click `index.html` and choose **Open with Live Server**.
