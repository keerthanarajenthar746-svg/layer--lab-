# 🏛️ Layer Lab Architecture & Core Concepts

## 1. The Core Philosophy
In traditional graphic design software (Photoshop, Canva, Figma), history is global: undoing a temporary product edit can accidentally revert or distort the carefully balanced brand framing, typography, or watermarks.

**Layer Lab** introduces an **Isolated Dual-Layer Architecture**:
1. **Layer 1: Brand Master Layer (Static / Protected 🔒)**
2. **Layer 2: Dynamic Product Layer (Editable ⚡)**

---

## 2. Component Hierarchy

```
LayerLabApp (Controller)
├── CanvasEngine
│   ├── renderBrandLayer()     <-- Static (Theme, Monogram, Borders, Footers)
│   └── renderProductLayer()   <-- Dynamic (Product Image, Price, Badges, Copy)
├── SmartAiEngine
│   ├── generateLocally()      <-- Offline NLP entity extractor & vector synthesizer
│   └── callGeminiAPI()        <-- Optional live Gemini Cloud API connector
└── HistoryManager
    ├── productUndoStack[]     <-- Product history (Price, Images, Badges)
    └── brandUndoStack[]       <-- Master Brand theme history (Only active when unlocked)
```

---

## 3. Scoped Undo / Redo Mechanism

When a user executes `Ctrl+Z` (Undo):
1. `HistoryManager.undo(isBrandModeUnlocked)` checks the current state.
2. If `isBrandModeUnlocked == false` (Default Protected Mode):
   - It only pops from `productUndoStack`.
   - Brand state is completely untouched and intact.
   - Triggers UI Toast: `"Undid Product Action (🛡️ Brand Kept Static)"`.
3. If `isBrandModeUnlocked == true` (Brand Design Mode):
   - Pops from `brandUndoStack`.
   - Modifies theme typography and layout.

---

## 4. Canvas Coordinate Scaling & High-DPI
The CanvasEngine operates on a logical **1080 x 1080** coordinate matrix regardless of device screen size:
- Screen resize computes `scaleFactorX` and `scaleFactorY`.
- On export, `render(true)` sets physical resolution to **2160 x 2160 (2x Retina)** for lossless downloads.
