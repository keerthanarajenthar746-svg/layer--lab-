// Layer Lab - Scoped History & Undo/Redo Engine
// Strictly isolates Product changes from Brand Theme changes to prevent accidental undo of perfected brand designs.

export class HistoryManager {
  constructor(options = {}) {
    this.maxHistory = options.maxHistory || 40;
    this.productUndoStack = [];
    this.productRedoStack = [];
    this.brandUndoStack = [];
    this.brandRedoStack = [];

    // Callbacks for UI updates
    this.onHistoryChange = options.onHistoryChange || (() => {});
    this.onToast = options.onToast || (() => {});
  }

  // Clone state deeply to prevent reference bugs
  clone(state) {
    return JSON.parse(JSON.stringify(state));
  }

  /**
   * Push a new dynamic product state
   * @param {string} label Short descriptive action (e.g. 'Changed Price to $29', 'Replaced Product Image')
   * @param {object} productState Current product state
   */
  pushProductState(label, productState) {
    this.productUndoStack.push({
      label,
      state: this.clone(productState),
      timestamp: Date.now()
    });

    if (this.productUndoStack.length > this.maxHistory) {
      this.productUndoStack.shift();
    }

    // Clear product redo stack on new action
    this.productRedoStack = [];
    this.notify();
  }

  /**
   * Push a new brand theme state (Only active when Brand Mode is unlocked)
   * @param {string} label Short descriptive action (e.g. 'Updated Brand Palette', 'Changed Logo')
   * @param {object} brandState Current brand state
   */
  pushBrandState(label, brandState) {
    this.brandUndoStack.push({
      label,
      state: this.clone(brandState),
      timestamp: Date.now()
    });

    if (this.brandUndoStack.length > this.maxHistory) {
      this.brandUndoStack.shift();
    }

    this.brandRedoStack = [];
    this.notify();
  }

  /**
   * Undo action based on the active mode (or scoped to product)
   * In Brand-Protected Mode: ALWAYS undos product state ONLY, preserving brand master layout!
   */
  undo(isBrandModeUnlocked, currentProductState, currentBrandState) {
    if (isBrandModeUnlocked) {
      // In Brand Mode, undo Brand state
      if (this.brandUndoStack.length <= 1) {
        this.onToast('No earlier brand changes to undo', 'info');
        return null;
      }
      const current = this.brandUndoStack.pop();
      this.brandRedoStack.push(current);
      const previous = this.brandUndoStack[this.brandUndoStack.length - 1];
      this.notify();
      this.onToast(`Undid: ${current.label} (Brand Mode)`, 'info');
      return { type: 'brand', state: this.clone(previous.state) };
    } else {
      // In Brand-Protected Mode (Standard): undo PRODUCT state ONLY
      if (this.productUndoStack.length <= 1) {
        this.onToast('No earlier product changes to undo', 'info');
        return null;
      }
      const current = this.productUndoStack.pop();
      this.productRedoStack.push(current);
      const previous = this.productUndoStack[this.productUndoStack.length - 1];
      this.notify();
      this.onToast(`Undid: ${current.label} (🛡️ Brand Kept Static)`, 'success');
      return { type: 'product', state: this.clone(previous.state) };
    }
  }

  /**
   * Redo action based on active mode
   */
  redo(isBrandModeUnlocked) {
    if (isBrandModeUnlocked) {
      if (this.brandRedoStack.length === 0) {
        this.onToast('Nothing to redo in Brand Mode', 'info');
        return null;
      }
      const next = this.brandRedoStack.pop();
      this.brandUndoStack.push(next);
      this.notify();
      this.onToast(`Redid: ${next.label} (Brand Mode)`, 'info');
      return { type: 'brand', state: this.clone(next.state) };
    } else {
      if (this.productRedoStack.length === 0) {
        this.onToast('Nothing to redo in Product Mode', 'info');
        return null;
      }
      const next = this.productRedoStack.pop();
      this.productUndoStack.push(next);
      this.notify();
      this.onToast(`Redid: ${next.label} (🛡️ Brand Kept Static)`, 'success');
      return { type: 'product', state: this.clone(next.state) };
    }
  }

  canUndo(isBrandModeUnlocked) {
    if (isBrandModeUnlocked) {
      return this.brandUndoStack.length > 1;
    }
    return this.productUndoStack.length > 1;
  }

  canRedo(isBrandModeUnlocked) {
    if (isBrandModeUnlocked) {
      return this.brandRedoStack.length > 0;
    }
    return this.productRedoStack.length > 0;
  }

  getHistoryLogs(isBrandModeUnlocked) {
    const list = isBrandModeUnlocked ? this.brandUndoStack : this.productUndoStack;
    return list.slice().reverse().map((item, idx) => ({
      index: list.length - 1 - idx,
      isCurrent: idx === 0,
      label: item.label,
      time: new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    }));
  }

  notify() {
    this.onHistoryChange({
      canUndoProduct: this.productUndoStack.length > 1,
      canRedoProduct: this.productRedoStack.length > 0,
      canUndoBrand: this.brandUndoStack.length > 1,
      canRedoBrand: this.brandRedoStack.length > 0,
      productCount: this.productUndoStack.length,
      brandCount: this.brandUndoStack.length
    });
  }
}
