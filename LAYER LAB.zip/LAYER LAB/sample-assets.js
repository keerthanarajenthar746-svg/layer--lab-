// Layer Lab - Dynamic Generative SVG Library
// Provides parametric vector graphics for any product category

export function generateSneakerSvg(color = '#ef4444', accent = '#18181b') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="snkSole" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#f8fafc" />
        <stop offset="100%" stop-color="#cbd5e1" />
      </linearGradient>
      <filter id="snkShadow">
        <feDropShadow dx="0" dy="18" stdDeviation="16" flood-color="#000" flood-opacity="0.35"/>
      </filter>
    </defs>
    <g filter="url(#snkShadow)">
      <!-- Sole Base -->
      <path d="M 70 290 Q 60 270 90 270 L 290 270 Q 340 270 335 300 L 320 315 Q 260 320 180 320 Q 90 320 70 290 Z" fill="url(#snkSole)" stroke="#94a3b8" stroke-width="2"/>
      <!-- Midsole Cushion -->
      <path d="M 75 272 L 315 272 Q 330 272 325 290 L 80 290 Z" fill="${accent}"/>
      <!-- Upper Body -->
      <path d="M 85 270 C 80 230 110 200 150 190 L 220 140 Q 250 130 270 170 L 305 240 Q 320 270 295 270 Z" fill="${color}"/>
      <!-- Toe Cap Overlay -->
      <path d="M 85 270 Q 75 240 110 235 L 145 270 Z" fill="${accent}" opacity="0.85"/>
      <!-- Dynamic Swoosh / Stripe -->
      <path d="M 120 245 Q 190 260 260 190 Q 210 240 150 250 Z" fill="#ffffff" opacity="0.95"/>
      <!-- Collar & Tongue -->
      <path d="M 210 145 L 245 130 Q 265 140 255 175 Z" fill="${accent}"/>
      <!-- Laces -->
      <line x1="175" y1="180" x2="215" y2="165" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
      <line x1="185" y1="200" x2="225" y2="185" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
      <line x1="195" y1="220" x2="235" y2="205" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
      <!-- Air Cushion Window -->
      <rect x="250" y="295" width="45" height="12" rx="6" fill="#38bdf8" opacity="0.85"/>
    </g>
  </svg>`;
}

export function generateWatchSvg(metal = '#fbbf24', dial = '#0f172a') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="metalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${metal}" />
        <stop offset="50%" stop-color="#fef08a" />
        <stop offset="100%" stop-color="${metal}" />
      </linearGradient>
      <filter id="watchShadow">
        <feDropShadow dx="0" dy="18" stdDeviation="15" flood-color="#000" flood-opacity="0.38"/>
      </filter>
    </defs>
    <g filter="url(#watchShadow)">
      <!-- Top Strap -->
      <path d="M 155 70 L 245 70 L 235 150 L 165 150 Z" fill="#1e293b" stroke="#334155" stroke-width="2"/>
      <line x1="160" y1="90" x2="240" y2="90" stroke="${metal}" stroke-width="2" opacity="0.4"/>
      <line x1="162" y1="110" x2="238" y2="110" stroke="${metal}" stroke-width="2" opacity="0.4"/>
      <!-- Bottom Strap -->
      <path d="M 165 250 L 235 250 L 245 330 L 155 330 Z" fill="#1e293b" stroke="#334155" stroke-width="2"/>
      <line x1="162" y1="290" x2="238" y2="290" stroke="${metal}" stroke-width="2" opacity="0.4"/>
      <line x1="160" y1="310" x2="240" y2="310" stroke="${metal}" stroke-width="2" opacity="0.4"/>
      <!-- Watch Crown Button -->
      <rect x="282" y="190" width="16" height="20" rx="3" fill="url(#metalGrad)"/>
      <!-- Outer Bezel -->
      <circle cx="200" cy="200" r="92" fill="url(#metalGrad)" stroke="#78350f" stroke-width="2"/>
      <circle cx="200" cy="200" r="82" fill="${dial}"/>
      <!-- Inner Bezel Ring -->
      <circle cx="200" cy="200" r="76" fill="none" stroke="${metal}" stroke-width="1.5" opacity="0.6"/>
      <!-- Hour Marks -->
      <circle cx="200" cy="132" r="4" fill="${metal}"/>
      <circle cx="268" cy="200" r="4" fill="${metal}"/>
      <circle cx="200" cy="268" r="4" fill="${metal}"/>
      <circle cx="132" cy="200" r="4" fill="${metal}"/>
      <!-- Subdials -->
      <circle cx="200" cy="170" r="16" fill="none" stroke="${metal}" stroke-width="1" opacity="0.5"/>
      <circle cx="175" cy="215" r="14" fill="none" stroke="${metal}" stroke-width="1" opacity="0.5"/>
      <!-- Watch Hands -->
      <line x1="200" y1="200" x2="200" y2="148" stroke="url(#metalGrad)" stroke-width="4" stroke-linecap="round"/>
      <line x1="200" y1="200" x2="235" y2="185" stroke="url(#metalGrad)" stroke-width="3" stroke-linecap="round"/>
      <line x1="200" y1="200" x2="180" y2="230" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round"/>
      <!-- Center Pin -->
      <circle cx="200" cy="200" r="5" fill="${metal}"/>
    </g>
  </svg>`;
}

export function generatePerfumeSvg(color = '#f43f5e', accent = '#fbbf24') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="perfGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.85" />
        <stop offset="50%" stop-color="#ffffff" stop-opacity="0.9" />
        <stop offset="100%" stop-color="${color}" stop-opacity="0.85" />
      </linearGradient>
      <filter id="perfShadow">
        <feDropShadow dx="0" dy="18" stdDeviation="16" flood-color="#000" flood-opacity="0.25"/>
      </filter>
    </defs>
    <g filter="url(#perfShadow)">
      <!-- Spray Cap -->
      <rect x="175" y="80" width="50" height="55" rx="6" fill="#18181b" stroke="${accent}" stroke-width="2"/>
      <!-- Gold Spray Collar -->
      <rect x="170" y="135" width="60" height="22" rx="4" fill="${accent}"/>
      <!-- Crystal Bottle Body -->
      <rect x="130" y="157" width="140" height="175" rx="20" fill="url(#perfGrad)" stroke="#ffffff" stroke-width="3"/>
      <!-- Glass Chamfer Highlight -->
      <path d="M 145 175 L 145 310" stroke="#ffffff" stroke-width="4" stroke-linecap="round" opacity="0.6"/>
      <!-- Fragrance Label Plaque -->
      <rect x="150" y="200" width="100" height="85" rx="6" fill="#ffffff" stroke="${accent}" stroke-width="1.5"/>
      <text x="200" y="228" font-family="serif" font-weight="bold" font-size="12" fill="#18181b" text-anchor="middle" letter-spacing="2">PARFUM</text>
      <line x1="165" y1="236" x2="235" y2="236" stroke="${accent}" stroke-width="1"/>
      <text x="200" y="252" font-family="sans-serif" font-size="8" fill="#64748b" text-anchor="middle">EAU DE PARFUM</text>
      <text x="200" y="268" font-family="sans-serif" font-size="8" fill="#94a3b8" text-anchor="middle">50 ML • 1.7 FL OZ</text>
    </g>
  </svg>`;
}

export function generateCandleSvg(color = '#fed7aa', accent = '#d97706') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <radialGradient id="flameGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#fef08a" />
        <stop offset="40%" stop-color="#f59e0b" />
        <stop offset="100%" stop-color="transparent" />
      </radialGradient>
      <filter id="candleShadow">
        <feDropShadow dx="0" dy="18" stdDeviation="15" flood-color="#000" flood-opacity="0.25"/>
      </filter>
    </defs>
    <g filter="url(#candleShadow)">
      <!-- Flame Glow Aura -->
      <circle cx="200" cy="115" r="45" fill="url(#flameGlow)" opacity="0.6"/>
      <!-- Flame Core -->
      <path d="M 200 90 Q 212 115 200 125 Q 188 115 200 90 Z" fill="#fef08a"/>
      <circle cx="200" cy="118" r="4" fill="#ef4444"/>
      <!-- Wick -->
      <line x1="200" y1="125" x2="200" y2="145" stroke="#1c1917" stroke-width="3" stroke-linecap="round"/>
      <!-- Candle Tumbler / Jar -->
      <rect x="135" y="145" width="130" height="180" rx="14" fill="#292524" stroke="${accent}" stroke-width="2"/>
      <!-- Wax Top Level -->
      <ellipse cx="200" cy="148" rx="65" ry="12" fill="${color}"/>
      <ellipse cx="200" cy="148" rx="55" ry="8" fill="#ffedd5" opacity="0.7"/>
      <!-- Matte Minimalist Label -->
      <rect x="150" y="195" width="100" height="95" rx="4" fill="#fafaf9"/>
      <text x="200" y="225" font-family="serif" font-weight="bold" font-size="11" fill="#292524" text-anchor="middle" letter-spacing="1.5">SOY CANDLE</text>
      <line x1="165" y1="234" x2="235" y2="234" stroke="${accent}" stroke-width="1"/>
      <text x="200" y="250" font-family="sans-serif" font-size="8" fill="#78716c" text-anchor="middle">AMBER & VANILLA</text>
      <text x="200" y="266" font-family="sans-serif" font-size="7" fill="#a8a29e" text-anchor="middle">60 HR BURN TIME</text>
    </g>
  </svg>`;
}

export function generateSmartPhoneSvg(color = '#0284c7') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="phoneScreen" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${color}" />
        <stop offset="50%" stop-color="#6366f1" />
        <stop offset="100%" stop-color="#0f172a" />
      </linearGradient>
      <filter id="phoneShadow">
        <feDropShadow dx="0" dy="20" stdDeviation="16" flood-color="#000" flood-opacity="0.35"/>
      </filter>
    </defs>
    <g filter="url(#phoneShadow)">
      <!-- Outer Metal Chassis -->
      <rect x="130" y="70" width="140" height="260" rx="28" fill="#1e293b" stroke="#64748b" stroke-width="2.5"/>
      <!-- Screen Bezel -->
      <rect x="135" y="75" width="130" height="250" rx="24" fill="url(#phoneScreen)"/>
      <!-- Dynamic Island / Camera Pill -->
      <rect x="175" y="84" width="50" height="14" rx="7" fill="#020617"/>
      <circle cx="212" cy="91" r="3" fill="#1e293b"/>
      <!-- Screen UI Graphic -->
      <circle cx="200" cy="180" r="35" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.4"/>
      <path d="M 180 180 L 220 180" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
      <text x="200" y="250" font-family="sans-serif" font-weight="bold" font-size="14" fill="#ffffff" text-anchor="middle">NEXUS PRO</text>
      <text x="200" y="268" font-family="sans-serif" font-size="9" fill="#94a3b8" text-anchor="middle">TITANIUM EDITION</text>
    </g>
  </svg>`;
}

export function generateUniversalProductSvg(title = 'Product', color = '#8b5cf6') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="univGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${color}" />
        <stop offset="100%" stop-color="#090d16" />
      </linearGradient>
      <filter id="univShadow">
        <feDropShadow dx="0" dy="20" stdDeviation="18" flood-color="#000" flood-opacity="0.4"/>
      </filter>
    </defs>
    <g filter="url(#univShadow)">
      <!-- Showcase Pedestal -->
      <ellipse cx="200" cy="315" rx="100" ry="24" fill="${color}" opacity="0.35"/>
      <ellipse cx="200" cy="310" rx="85" ry="18" fill="#1e293b" stroke="${color}" stroke-width="2"/>
      <!-- Product Gift / Showcase Box -->
      <rect x="135" y="140" width="130" height="150" rx="18" fill="url(#univGrad)" stroke="#ffffff" stroke-width="2"/>
      <!-- Luxury Ribbon Vertical -->
      <rect x="188" y="140" width="24" height="150" fill="#facc15" opacity="0.9"/>
      <!-- Ribbon Bow -->
      <circle cx="200" cy="138" r="16" fill="#eab308"/>
      <circle cx="200" cy="138" r="8" fill="#ca8a04"/>
      <!-- Sparkle Stars -->
      <path d="M 120 120 Q 120 135 105 135 Q 120 135 120 150 Q 120 135 135 135 Q 120 135 120 120 Z" fill="#fef08a"/>
      <path d="M 280 125 Q 280 140 265 140 Q 280 140 280 155 Q 280 140 295 140 Q 280 140 280 125 Z" fill="#fef08a"/>
      <!-- Text Badge -->
      <rect x="150" y="200" width="100" height="40" rx="8" fill="#000000" opacity="0.65"/>
      <text x="200" y="225" font-family="sans-serif" font-weight="bold" font-size="12" fill="#ffffff" text-anchor="middle">${title.substring(0, 10).toUpperCase()}</text>
    </g>
  </svg>`;
}
