# 🎨 Layer Lab - Brand-Protected Product Design Studio & AI Magic Generator

> **"Never accidentally undo your perfected brand design again."**

**Layer Lab** solves a universal dilemma for small business owners and designers: when experimenting with product photos, prices, or promotional badges, traditional design tools' global `Undo` (`Ctrl+Z`) accidentally rolls back the perfected brand typography, frame layout, and colors.

With **Layer Lab**, your master brand theme stays locked in a **Static Protected Mode**, allowing you to enter natural language AI prompts, hot-swap products, test discounts, and press undo freely without ever breaking your brand identity.

---

## 🌟 Key Features

- ✨ **AI Creative Studio (Prompt to Creative):**
  - Type any natural language prompt (e.g., *"Flash sale for organic rose face serum with 30% OFF badge, price $32 (was $48)"*).
  - The AI assistant extracts products, prices, discounts, and matching aesthetics with 1 click.
  - Choose between **🛡️ Brand-Safe Mode** (AI only designs the product layer while preserving your brand) or **🎨 Full Remake Mode**.
- 🛡️ **Brand Protected Layer (Static Master):** Locks brand name, monogram logo, tagline, aesthetic frame, social handles, and palette. Untouchable by accidental clicks or undos.
- ⚡ **Dynamic Product Layer:** Freely add, resize, swap, and reposition product cutouts, price tags, and promotional badges.
- 🔄 **Isolated Safe-Undo Engine:** Pressing `Ctrl+Z` rolls back only product actions. Your brand design is 100% preserved.
- 📦 **1-Click Built-in Catalog:** Pre-loaded with 5 instant business products (Fashion Handbag, Specialty Coffee, Wireless Headphones, Skincare Serum, Stoneware Ceramics).
- 📸 **Custom Product Upload:** Upload your own transparent PNG or JPG with drag & resize handles.
- 📐 **Social Media Ready:** 1-click toggle between Square (1:1), Story/Reels (9:16), and Banner (16:9).
- 💾 **Instant High-Res Export:** Download pristine 2x Retina PNGs, compressed JPGs, or copy directly to clipboard.

---

## 🚀 Quick Start

1. Clone or download this repository.
2. Open `index.html` in any web browser (no installation, Node.js, or server required).
3. Type an AI prompt in **✨ AI Studio**, or manually customize and export in seconds!

---

## 🛠️ Built With

- **HTML5 Canvas API** (Dual-layer high-DPI rendering engine)
- **Tailwind CSS** (Modern responsive design & glassmorphism)
- **Smart NLP & AI Engine** (Works 100% offline or with optional Google Gemini API key)
- **Vanilla JavaScript (ES6+)** (Zero-dependency scoped state & undo management)
