// Layer Lab - Dedicated Generative AI Studio Engine
// Parses natural language prompts into product copy, pricing, badges, and matching vector assets

import {
  generateSneakerSvg,
  generateWatchSvg,
  generatePerfumeSvg,
  generateCandleSvg,
  generateUniversalProductSvg,
  svgToDataUrl
} from './sample-assets.js';
import { BRAND_TEMPLATES } from './templates.js';

export class SmartAiEngine {
  constructor() {
    this.apiKey = localStorage.getItem('layer_lab_gemini_key') || '';
  }

  setApiKey(key) {
    this.apiKey = key;
    localStorage.setItem('layer_lab_gemini_key', key);
  }

  async generateFromPrompt(rawPrompt, scope = 'product-only', currentBrandState, sampleProducts = []) {
    const prompt = (rawPrompt || '').trim();
    if (!prompt) return null;

    if (this.apiKey) {
      try {
        const cloudResult = await this.callGeminiAPI(prompt, sampleProducts);
        if (cloudResult) return cloudResult;
      } catch (e) {
        console.warn('Gemini cloud call failed, using intelligent offline parser', e);
      }
    }

    return this.generateLocally(prompt, scope, sampleProducts);
  }

  generateLocally(prompt, scope, sampleProducts = []) {
    const lower = prompt.toLowerCase();

    // 1. Color Extraction
    let primaryColor = '#38bdf8';
    let accentColor = '#fbbf24';

    if (lower.includes('red') || lower.includes('crimson') || lower.includes('ruby')) {
      primaryColor = '#ef4444';
      accentColor = '#18181b';
    } else if (lower.includes('blue') || lower.includes('cyan') || lower.includes('neon') || lower.includes('electric')) {
      primaryColor = '#0284c7';
      accentColor = '#38bdf8';
    } else if (lower.includes('gold') || lower.includes('yellow') || lower.includes('champagne')) {
      primaryColor = '#fbbf24';
      accentColor = '#d97706';
    } else if (lower.includes('green') || lower.includes('emerald') || lower.includes('botanical') || lower.includes('sage')) {
      primaryColor = '#10b981';
      accentColor = '#065f46';
    } else if (lower.includes('purple') || lower.includes('violet') || lower.includes('lavender')) {
      primaryColor = '#8b5cf6';
      accentColor = '#4c1d95';
    } else if (lower.includes('pink') || lower.includes('rose') || lower.includes('blush') || lower.includes('pastel')) {
      primaryColor = '#f43f5e';
      accentColor = '#fbbf24';
    } else if (lower.includes('orange') || lower.includes('terracotta') || lower.includes('amber')) {
      primaryColor = '#ea580c';
      accentColor = '#7c2d12';
    } else if (lower.includes('black') || lower.includes('dark') || lower.includes('obsidian')) {
      primaryColor = '#18181b';
      accentColor = '#e2e8f0';
    }

    // 2. Category Detection & Visual Asset Generation
    let svgContent = '';
    let defaultName = 'Artisan Product';
    let defaultPrice = '$49.00';
    let defaultDesc = 'Handcrafted premium quality with signature aesthetic finish';
    let themeIndex = 0;

    if (lower.includes('shoe') || lower.includes('sneaker') || lower.includes('kicks') || lower.includes('footwear') || lower.includes('runner') || lower.includes('boot')) {
      svgContent = generateSneakerSvg(primaryColor, accentColor);
      defaultName = 'Air Pulse Sport Sneaker';
      defaultPrice = '$89.00';
      defaultDesc = 'Ultra-responsive cushioning with breathable mesh and grip sole';
      themeIndex = 2;
    } else if (lower.includes('watch') || lower.includes('chronometer') || lower.includes('timepiece') || lower.includes('rolex') || lower.includes('dial')) {
      svgContent = generateWatchSvg(accentColor || '#fbbf24', '#0f172a');
      defaultName = 'Chronos Master Chronometer';
      defaultPrice = '$299.00';
      defaultDesc = 'Swiss automatic movement with scratch-resistant sapphire crystal';
      themeIndex = 0;
    } else if (lower.includes('perfume') || lower.includes('fragrance') || lower.includes('cologne') || lower.includes('scent') || lower.includes('parfum')) {
      svgContent = generatePerfumeSvg(primaryColor, accentColor);
      defaultName = 'Velvet Orchid Eau De Parfum';
      defaultPrice = '$58.00';
      defaultDesc = 'Rich notes of bourbon vanilla, sensual amber & fresh bergamot';
      themeIndex = 0;
    } else if (lower.includes('candle') || lower.includes('wax') || lower.includes('aroma') || lower.includes('wick')) {
      svgContent = generateCandleSvg('#fed7aa', primaryColor);
      defaultName = 'Nordic Amber Soy Candle';
      defaultPrice = '$28.00';
      defaultDesc = 'Hand-poured coconut soy wax with natural crackling wooden wick';
      themeIndex = 4;
    } else if (lower.includes('headphone') || lower.includes('audio') || lower.includes('sound') || lower.includes('earbud') || lower.includes('speaker') || lower.includes('wireless') || lower.includes('anc')) {
      svgContent = (sampleProducts[2] && sampleProducts[2].svg) || '';
      defaultName = 'AeroTune Pro ANC Wireless';
      defaultPrice = '$149.00';
      defaultDesc = 'Hi-Res Spatial Audio with 40-hour battery and smart active noise cancel';
      themeIndex = 2;
    } else if (lower.includes('serum') || lower.includes('skin') || lower.includes('botanical') || lower.includes('cream') || lower.includes('lotion') || lower.includes('face') || lower.includes('elixir') || lower.includes('glow')) {
      svgContent = (sampleProducts[3] && sampleProducts[3].svg) || '';
      defaultName = 'Glow Botanical Face Elixir';
      defaultPrice = '$42.00';
      defaultDesc = 'Cold-pressed Rosehip & Vitamin C for luminous skin barrier repair';
      themeIndex = 3;
    } else if (lower.includes('coffee') || lower.includes('bean') || lower.includes('roast') || lower.includes('cafe') || lower.includes('espresso') || lower.includes('brew') || lower.includes('tea')) {
      svgContent = (sampleProducts[1] && sampleProducts[1].svg) || '';
      defaultName = 'Highland Reserve Coffee Roast';
      defaultPrice = '$22.00';
      defaultDesc = 'Washed single-origin beans with tasting notes of honey, citrus & cocoa';
      themeIndex = 1;
    } else if (lower.includes('mug') || lower.includes('ceramic') || lower.includes('pottery') || lower.includes('clay') || lower.includes('stoneware') || lower.includes('handcrafted')) {
      svgContent = (sampleProducts[4] && sampleProducts[4].svg) || '';
      defaultName = 'Wabi-Sabi Speckled Mug';
      defaultPrice = '$34.00';
      defaultDesc = 'Wheel-thrown artisanal stoneware with toasted iron-fleck glaze';
      themeIndex = 4;
    } else if (lower.includes('bag') || lower.includes('leather') || lower.includes('purse') || lower.includes('tote') || lower.includes('crossbody') || lower.includes('backpack')) {
      svgContent = (sampleProducts[0] && sampleProducts[0].svg) || '';
      defaultName = 'Verona Pebble Leather Tote';
      defaultPrice = '$135.00';
      defaultDesc = 'Full-grain Italian calfskin with brushed gold hardware and zip closure';
      themeIndex = 0;
    } else {
      defaultName = this.extractTitle(prompt) || 'Custom Designer Edition';
      svgContent = generateUniversalProductSvg(defaultName, primaryColor);
      defaultPrice = '$49.00';
      defaultDesc = 'Crafted with premium materials and signature artisan design';
      themeIndex = 0;
    }

    // 3. Price & Strike Price Extraction
    let price = defaultPrice;
    let originalPrice = '';

    const priceRegex = /\$\s*([0-9]+(?:\.[0-9]{2})?)/g;
    const dollarMatches = prompt.match(priceRegex);

    if (dollarMatches && dollarMatches.length > 0) {
      price = dollarMatches[0].replace(/\s+/g, '');
      if (dollarMatches.length > 1) {
        originalPrice = dollarMatches[1].replace(/\s+/g, '');
      }
    } else {
      const numMatch = prompt.match(/(?:price|cost|for|only)?\s*([0-9]{1,4})\s*(?:dollars|bucks|usd|\$)/i) || prompt.match(/price\s*(?:is|of|:)?\s*([0-9]{1,4})/i);
      if (numMatch && numMatch[1]) {
        price = `$${parseInt(numMatch[1], 10)}.00`;
      }
    }

    const wasMatch = prompt.match(/(?:was|originally|before|from)\s*\$?([0-9]+(?:\.[0-9]{2})?)/i);
    if (wasMatch && wasMatch[1]) {
      originalPrice = `$${parseFloat(wasMatch[1]).toFixed(2)}`;
    }

    // 4. Promotional Badge Extraction
    let badge = 'NEW ARRIVAL';
    const discountMatch = prompt.match(/([0-9]{1,2}%\s*off)/i) || prompt.match(/([0-9]{1,2}%)\s*discount/i);

    if (discountMatch) {
      badge = discountMatch[1].toUpperCase();
      if (!originalPrice && price) {
        const priceNum = parseFloat(price.replace('$', ''));
        const pct = parseInt(discountMatch[1], 10);
        if (priceNum > 0 && pct > 0 && pct < 90) {
          originalPrice = `$${(priceNum / (1 - pct / 100)).toFixed(2)}`;
        }
      }
    } else if (lower.includes('flash sale')) {
      badge = 'FLASH SALE';
    } else if (lower.includes('limited')) {
      badge = 'LIMITED EDITION';
    } else if (lower.includes('best seller') || lower.includes('bestseller')) {
      badge = 'BEST SELLER';
    } else if (lower.includes('organic')) {
      badge = '100% ORGANIC';
    } else if (lower.includes('handmade') || lower.includes('handcrafted')) {
      badge = 'HANDCRAFTED';
    } else if (lower.includes('bogo') || lower.includes('buy 1 get 1')) {
      badge = 'BUY 1 GET 1';
    } else if (lower.includes('hot deal') || lower.includes('deal')) {
      badge = 'HOT DEAL';
    }

    const name = this.extractTitle(prompt) || defaultName;

    const generatedProduct = {
      name,
      price,
      originalPrice,
      badge,
      badgeColor: primaryColor,
      description: defaultDesc,
      svgDataUrl: svgToDataUrl(svgContent),
      imageUrl: null,
      scale: 0.95,
      posX: 0,
      posY: 10
    };

    let generatedBrand = null;
    if (scope === 'full-creative') {
      const baseTemplate = BRAND_TEMPLATES[themeIndex] || BRAND_TEMPLATES[0];
      generatedBrand = JSON.parse(JSON.stringify(baseTemplate.brand));
      generatedBrand.accentColor = accentColor;
      generatedBrand.badgeBgColor = primaryColor;

      if (lower.includes('sneaker') || lower.includes('shoe')) {
        generatedBrand.name = 'KINETIC KICKS LAB';
        generatedBrand.tagline = 'STREETWEAR & ATHLETIC PERFORMANCE';
      } else if (lower.includes('watch')) {
        generatedBrand.name = 'CHRONOS HAUTE HORLOGERIE';
        generatedBrand.tagline = 'GENÈVE • TIMELESS PRECISION';
      } else if (lower.includes('perfume')) {
        generatedBrand.name = 'MAISON DE FLEUR';
        generatedBrand.tagline = 'HAUTE PARFUMERIE • PARIS';
      } else if (lower.includes('candle')) {
        generatedBrand.name = 'LUMIÈRE ATELIER';
        generatedBrand.tagline = 'BOTANICAL SOY APOTHECARY';
      }
    }

    return {
      product: generatedProduct,
      brand: generatedBrand,
      summary: `✨ Created "${name}" (${price}) with badge [${badge}]`
    };
  }

  extractTitle(prompt) {
    if (!prompt) return '';
    let clean = prompt
      .replace(/(?:can\s+you\s+)?(?:create|make|generate|design|i\s+need|i\s+want|give\s+me|please)\s+(?:a|an|the)?/gi, '')
      .replace(/product\s+(?:for|of)?/gi, '')
      .replace(/(?:sale|banner|creative|post|ad)\s+for/gi, '')
      .replace(/\$\s*[0-9]+(?:\.[0-9]{2})?/g, '')
      .replace(/[0-9]{1,4}\s*(?:dollars|bucks|usd)/gi, '')
      .replace(/(?:was|originally)\s*\$?[0-9.]+/gi, '')
      .replace(/[0-9]{1,2}%\s*off/gi, '')
      .replace(/(?:flash\s+sale|limited\s+edition|best\s+seller|new\s+arrival)/gi, '')
      .replace(/with\s+(?:badge|price|discount|theme|aesthetic|vibe).*/gi, '')
      .replace(/[,.!?]/g, '')
      .trim();

    const words = clean.split(/\s+/).filter(w => w.length > 1 && !['with', 'for', 'and', 'the', 'price', 'badge'].includes(w.toLowerCase()));
    if (words.length >= 2) {
      return words.slice(0, 4).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
    } else if (words.length === 1) {
      return words[0].charAt(0).toUpperCase() + words[0].slice(1).toLowerCase() + ' Edition';
    }
    return '';
  }

  async callGeminiAPI(userPrompt, sampleProducts) {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.apiKey}`;
    const systemInstruction = `You are an AI graphic design assistant for Layer Lab. Given a user prompt for a product creative, output ONLY a valid JSON object matching this structure:
    {
      "name": "Product Title",
      "price": "$XX.XX",
      "originalPrice": "$XX.XX",
      "badge": "DISCOUNT OR BADGE",
      "description": "Short 1-line feature description",
      "category": "sneaker" or "watch" or "perfume" or "candle" or "coffee" or "headphones" or "serum" or "ceramic" or "handbag" or "universal"
    }`;

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: `${systemInstruction}\n\nUser Request: ${userPrompt}` }]
        }]
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return null;

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);

    let svg = '';
    if (parsed.category === 'sneaker') svg = generateSneakerSvg('#ef4444', '#18181b');
    else if (parsed.category === 'watch') svg = generateWatchSvg('#fbbf24', '#0f172a');
    else if (parsed.category === 'perfume') svg = generatePerfumeSvg('#f43f5e', '#fbbf24');
    else if (parsed.category === 'candle') svg = generateCandleSvg('#fed7aa', '#d97706');
    else if (parsed.category === 'coffee') svg = sampleProducts[1].svg;
    else if (parsed.category === 'headphones') svg = sampleProducts[2].svg;
    else if (parsed.category === 'serum') svg = sampleProducts[3].svg;
    else if (parsed.category === 'ceramic') svg = sampleProducts[4].svg;
    else if (parsed.category === 'handbag') svg = sampleProducts[0].svg;
    else svg = generateUniversalProductSvg(parsed.name, '#8b5cf6');

    return {
      product: {
        name: parsed.name,
        price: parsed.price || '$49.00',
        originalPrice: parsed.originalPrice || '',
        badge: parsed.badge || 'NEW ARRIVAL',
        badgeColor: '#38bdf8',
        description: parsed.description || 'Premium craftsmanship and signature design',
        svgDataUrl: svgToDataUrl(svg),
        imageUrl: null,
        scale: 0.95,
        posX: 0,
        posY: 10
      },
      brand: null,
      summary: `AI Generated: ${parsed.name}`
    };
  }
}
