// Layer Lab - Pre-built Brand Themes & Layout Templates
// Each theme defines the static brand master layer and the initial dynamic product setup

export const BRAND_TEMPLATES = [
  {
    id: 'theme-luxury',
    name: 'Velvet & Gold',
    category: 'Fashion & Luxury',
    icon: 'sparkles',
    aspectRatio: '1:1', // 1080x1080
    brand: {
      name: 'MAISON ÉLÉGANCE',
      tagline: 'PARIS • MILAN • NEW YORK',
      handle: '@maisonelegance • www.maisonelegance.com',
      fontFamily: `'Playfair Display', serif`,
      fontHeader: `'Cinzel', serif`,
      textColor: '#ffffff',
      accentColor: '#d4af37', // Gold
      badgeBgColor: '#d4af37',
      badgeTextColor: '#000000',
      backgroundType: 'gradient',
      bgGradientStart: '#18181b', // Obsidian dark
      bgGradientEnd: '#09090b',
      frameStyle: 'ornate-border', // ornate-border, modern-card, minimal-frame, full-bleed, polaroid
      watermarkText: 'ÉLÉGANCE COUTURE',
      showWatermark: true,
      logoMonogram: 'ME',
      badgePlacement: 'top-right'
    },
    defaultProduct: {
      name: 'Italian Leather Crossbody',
      price: '$129.00',
      originalPrice: '$180.00',
      badge: 'LIMITED EDITION',
      description: 'Hand-stitched calfskin with brushed gold hardware',
      sampleId: 'prod-handbag',
      scale: 0.95,
      posX: 0,
      posY: 10
    }
  },
  {
    id: 'theme-nordic',
    name: 'Nordic Roast',
    category: 'Cafe & Pantry',
    icon: 'coffee',
    aspectRatio: '1:1',
    brand: {
      name: 'FJORD COFFEE ROASTERS',
      tagline: 'ORGANIC SMALL-BATCH SPECIALTY BEANS',
      handle: '@fjordroasters • fjordcoffee.co',
      fontFamily: `'Plus Jakarta Sans', sans-serif`,
      fontHeader: `'Space Grotesk', sans-serif`,
      textColor: '#292524',
      accentColor: '#b45309',
      badgeBgColor: '#15803d',
      badgeTextColor: '#ffffff',
      backgroundType: 'warm-cream',
      bgGradientStart: '#fef3c7',
      bgGradientEnd: '#fde68a',
      frameStyle: 'minimal-frame',
      watermarkText: 'EST. 2018',
      showWatermark: true,
      logoMonogram: '☕ FJ',
      badgePlacement: 'top-left'
    },
    defaultProduct: {
      name: 'Artisan Ethiopian Roast',
      price: '$21.50',
      originalPrice: '$26.00',
      badge: 'FRESH ROAST',
      description: 'Floral jasmine, bergamot notes, washed medium roast',
      sampleId: 'prod-coffee',
      scale: 0.92,
      posX: 0,
      posY: 15
    }
  },
  {
    id: 'theme-tech',
    name: 'Cyber Pulse',
    category: 'Tech & Gaming',
    icon: 'cpu',
    aspectRatio: '1:1',
    brand: {
      name: 'NEXUS SOUND LABS',
      tagline: 'NEXT-GEN ACOUSTIC ARCHITECTURE',
      handle: '@nexussound • shopnexus.io',
      fontFamily: `'Inter', sans-serif`,
      fontHeader: `'Space Grotesk', sans-serif`,
      textColor: '#f8fafc',
      accentColor: '#38bdf8', // Neon Sky Blue
      badgeBgColor: '#2563eb',
      badgeTextColor: '#ffffff',
      backgroundType: 'neon-dark',
      bgGradientStart: '#0f172a',
      bgGradientEnd: '#020617',
      frameStyle: 'modern-card',
      watermarkText: 'NEXUS AUDIO',
      showWatermark: true,
      logoMonogram: '⟐ NX',
      badgePlacement: 'top-right'
    },
    defaultProduct: {
      name: 'AeroTune Pro ANC',
      price: '$249.99',
      originalPrice: '$299.99',
      badge: 'FLASH SALE',
      description: 'Active Noise Canceling with 40hr Battery & Spatial Audio',
      sampleId: 'prod-headphones',
      scale: 0.95,
      posX: 0,
      posY: 10
    }
  },
  {
    id: 'theme-botanical',
    name: 'Botanical Glow',
    category: 'Skincare & Wellness',
    icon: 'leaf',
    aspectRatio: '1:1',
    brand: {
      name: 'LUMEN BOTANICALS',
      tagline: 'PURE PLANT ALCHEMY FOR RADIANT SKIN',
      handle: '@lumenbotanicals • lumenbotanicals.com',
      fontFamily: `'Playfair Display', serif`,
      fontHeader: `'Playfair Display', serif`,
      textColor: '#1c1917',
      accentColor: '#059669', // Emerald Green
      badgeBgColor: '#059669',
      badgeTextColor: '#ffffff',
      backgroundType: 'sage-light',
      bgGradientStart: '#f0fdf4',
      bgGradientEnd: '#dcfce7',
      frameStyle: 'ornate-border',
      watermarkText: 'CLEAN BEAUTY',
      showWatermark: true,
      logoMonogram: '🌿 LM',
      badgePlacement: 'top-left'
    },
    defaultProduct: {
      name: 'Glow Face Elixir Serum',
      price: '$44.00',
      originalPrice: '$55.00',
      badge: 'BEST SELLER',
      description: 'Cold-pressed Rosehip, Squalane & Vitamin C radiance serum',
      sampleId: 'prod-serum',
      scale: 0.95,
      posX: 0,
      posY: 12
    }
  },
  {
    id: 'theme-artisan',
    name: 'Earth & Clay',
    category: 'Crafts & Ceramics',
    icon: 'heart',
    aspectRatio: '1:1',
    brand: {
      name: 'TERRA STUDIO CO.',
      tagline: 'SMALL BATCH HANDMADE STONEWARE',
      handle: '@terrastudio • terraceramics.store',
      fontFamily: `'Plus Jakarta Sans', sans-serif`,
      fontHeader: `'Playfair Display', serif`,
      textColor: '#292524',
      accentColor: '#d97706', // Terracotta
      badgeBgColor: '#d97706',
      badgeTextColor: '#ffffff',
      backgroundType: 'terracotta-warm',
      bgGradientStart: '#fff7ed',
      bgGradientEnd: '#ffedd5',
      frameStyle: 'minimal-frame',
      watermarkText: 'POTTERY WORKS',
      showWatermark: true,
      logoMonogram: '🏺 TS',
      badgePlacement: 'top-right'
    },
    defaultProduct: {
      name: 'Wabi-Sabi Stoneware Mug',
      price: '$36.00',
      originalPrice: '$42.00',
      badge: 'HANDCRAFTED',
      description: 'Wheel-thrown speckled clay with toasted iron-fleck glaze',
      sampleId: 'prod-ceramic',
      scale: 0.95,
      posX: 0,
      posY: 10
    }
  }
];
