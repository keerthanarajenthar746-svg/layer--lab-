// Layer Lab - Main Application Controller (Modular ES6 Source)

import { BRAND_TEMPLATES } from './templates.js';
import { SAMPLE_PRODUCTS, svgToDataUrl } from './sample-assets.js';
import { HistoryManager } from './history.js';
import { CanvasEngine } from './canvas-engine.js';
import { SmartAiEngine } from './ai-engine.js';

export class LayerLabApp {
  constructor() {
    this.currentTemplateIndex = 0;
    this.currentTemplate = BRAND_TEMPLATES[0];

    this.brandState = JSON.parse(JSON.stringify(this.currentTemplate.brand));
    this.productState = JSON.parse(JSON.stringify(this.currentTemplate.defaultProduct));

    const initialSample = SAMPLE_PRODUCTS.find(p => p.id === this.productState.sampleId) || SAMPLE_PRODUCTS[0];
    this.productState.svgDataUrl = svgToDataUrl(initialSample.svg);
    this.productState.name = initialSample.name;
    this.productState.price = initialSample.price;
    this.productState.originalPrice = initialSample.originalPrice;
    this.productState.badge = initialSample.badge;
    this.productState.description = initialSample.description;

    this.isBrandModeUnlocked = false;
    this.currentAspectRatio = '1:1';

    this.aiEngine = new SmartAiEngine();

    this.initHistory();
    this.initCanvas();
    this.initDOM();
    this.bindEvents();

    this.syncFormFields();
    this.updateModeUI();
    this.canvasEngine.requestRender();
    this.showToast('Layer Lab Ready: AI Studio & Brand Protected 🔒', 'success');
  }

  initHistory() {
    this.history = new HistoryManager({
      onHistoryChange: (status) => this.updateHistoryUI(status),
      onToast: (msg, type) => this.showToast(msg, type)
    });
    this.history.pushBrandState('Initial Brand Setup', this.brandState);
    this.history.pushProductState('Initial Product Setup', this.productState);
  }

  initCanvas() {
    const canvas = document.getElementById('mainCanvas');
    this.canvasEngine = new CanvasEngine(canvas, {
      onStateModified: (label) => {
        this.history.pushProductState(label, this.productState);
        this.syncFormFields();
      }
    });
    this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
  }

  initDOM() {
    const templateSelect = document.getElementById('templateSelect');
    if (templateSelect) {
      templateSelect.innerHTML = BRAND_TEMPLATES.map((t, idx) =>
        `<option value="${idx}">${t.name} (${t.category})</option>`
      ).join('');
    }

    const sampleGrid = document.getElementById('sampleProductGrid');
    if (sampleGrid) {
      sampleGrid.innerHTML = SAMPLE_PRODUCTS.map((prod) => `
        <button data-prod-id="${prod.id}" class="sample-prod-btn p-1.5 rounded-xl border border-white/10 hover:border-cyan-400 bg-slate-900/60 hover:bg-slate-800 transition-all flex flex-col items-center group" title="${prod.name} (${prod.category})">
          <div class="w-12 h-12 flex items-center justify-center p-0.5 rounded-lg bg-black/40 group-hover:scale-105 transition-transform">
            <img src="${svgToDataUrl(prod.svg)}" alt="${prod.name}" class="w-11 h-11 object-contain pointer-events-none">
          </div>
          <span class="text-[9px] text-slate-300 font-medium truncate w-full text-center mt-1 group-hover:text-cyan-300">${prod.name.split(' ')[0]}</span>
        </button>
      `).join('');
    }

    const savedKey = localStorage.getItem('layer_lab_gemini_key');
    if (savedKey) {
      const inputApiKey = document.getElementById('inputApiKey');
      if (inputApiKey) inputApiKey.value = savedKey;
    }
  }

  bindEvents() {
    // 1. 4-Tab Navigation
    const tabs = [
      { btn: document.getElementById('tabAI'), panel: document.getElementById('panelAI'), isAI: true },
      { btn: document.getElementById('tabProducts'), panel: document.getElementById('panelProducts') },
      { btn: document.getElementById('tabBrand'), panel: document.getElementById('panelBrand') },
      { btn: document.getElementById('tabHistory'), panel: document.getElementById('panelHistory') }
    ];

    tabs.forEach(({ btn, panel, isAI }) => {
      if (!btn || !panel) return;
      btn.addEventListener('click', () => {
        tabs.forEach(t => {
          if (!t.btn || !t.panel) return;
          t.btn.classList.remove('active', 'text-cyan-400', 'bg-cyan-500/10', 'tab-btn-ai');
          t.btn.classList.add('text-slate-400');
          t.panel.classList.add('hidden');
        });

        if (isAI) {
          btn.classList.add('active', 'tab-btn-ai');
        } else {
          btn.classList.add('active', 'text-cyan-400', 'bg-cyan-500/10');
        }
        btn.classList.remove('text-slate-400');
        panel.classList.remove('hidden');
      });
    });

    // 2. AI Prompt Generation & Inspiration Chips
    const aiPromptInput = document.getElementById('aiPromptInput');
    const btnAiGenerate = document.getElementById('btnAiGenerate');
    const btnClearPrompt = document.getElementById('btnClearPrompt');

    if (btnClearPrompt && aiPromptInput) {
      btnClearPrompt.addEventListener('click', () => {
        aiPromptInput.value = '';
        aiPromptInput.focus();
      });
    }

    document.querySelectorAll('.ai-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const promptText = chip.getAttribute('data-prompt');
        if (aiPromptInput) {
          aiPromptInput.value = promptText;
          aiPromptInput.focus();
        }
        this.triggerAiGeneration();
      });
    });

    if (btnAiGenerate) {
      btnAiGenerate.addEventListener('click', () => {
        this.triggerAiGeneration();
      });
    }

    // AI Scope Radio Hint
    document.querySelectorAll('input[name="aiScope"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const hint = document.getElementById('aiScopeHint');
        if (!hint) return;
        if (radio.value === 'product-only') {
          hint.textContent = '✓ AI only updates product copy & visuals. Your master brand layout is preserved!';
          hint.className = 'text-[10px] text-emerald-400/90 leading-tight';
        } else {
          hint.textContent = '🎨 AI will craft a brand new brand aesthetic and matching product creative.';
          hint.className = 'text-[10px] text-purple-400/90 leading-tight';
        }
      });
    });

    // API Key Save
    const btnSaveApiKey = document.getElementById('btnSaveApiKey');
    if (btnSaveApiKey) {
      btnSaveApiKey.addEventListener('click', () => {
        const input = document.getElementById('inputApiKey');
        const val = input ? input.value.trim() : '';
        this.aiEngine.setApiKey(val);
        this.showToast(val ? 'Gemini API Key Saved!' : 'Cleared API Key (Using offline AI)', 'success');
      });
    }

    // 3. Brand Master Lock / Unlock Toggle
    const modeToggleBtn = document.getElementById('modeToggleBtn');
    const brandLockCheckbox = document.getElementById('brandLockCheckbox');

    const toggleLockMode = () => {
      this.isBrandModeUnlocked = !this.isBrandModeUnlocked;
      if (brandLockCheckbox) brandLockCheckbox.checked = !this.isBrandModeUnlocked;
      this.updateModeUI();
      this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);

      if (this.isBrandModeUnlocked) {
        this.showToast('Brand Mode Unlocked 🔓 (Editing Master Theme)', 'warning');
      } else {
        this.showToast('Brand Protected 🔒 (Product Edits Only)', 'success');
      }
    };

    if (modeToggleBtn) modeToggleBtn.addEventListener('click', toggleLockMode);
    if (brandLockCheckbox) {
      brandLockCheckbox.addEventListener('change', () => {
        this.isBrandModeUnlocked = !brandLockCheckbox.checked;
        this.updateModeUI();
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
    }

    // 4. Scoped Undo / Redo Controls
    const btnUndo = document.getElementById('btnUndo');
    const btnRedo = document.getElementById('btnRedo');

    if (btnUndo) btnUndo.addEventListener('click', () => this.handleUndo());
    if (btnRedo) btnRedo.addEventListener('click', () => this.handleRedo());

    window.addEventListener('keydown', (e) => {
      if (['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) this.handleRedo();
        else this.handleUndo();
        e.preventDefault();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        this.handleRedo();
        e.preventDefault();
      }
    });

    // 5. Sample Product Click
    document.querySelectorAll('.sample-prod-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const prodId = btn.getAttribute('data-prod-id');
        this.applySampleProduct(prodId);
      });
    });

    // Custom Image Upload
    const imageUploadInput = document.getElementById('imageUploadInput');
    if (imageUploadInput) {
      imageUploadInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
          this.productState.imageUrl = event.target.result;
          this.productState.svgDataUrl = null;
          this.productState.scale = 1.0;
          this.productState.posX = 0;
          this.productState.posY = 0;
          this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
          this.history.pushProductState('Uploaded Custom Product Photo', this.productState);
          this.syncFormFields();
          this.showToast('Custom product photo loaded!', 'success');
        };
        reader.readAsDataURL(file);
      });
    }

    const btnResetProductPos = document.getElementById('btnResetProductPos');
    if (btnResetProductPos) {
      btnResetProductPos.addEventListener('click', () => {
        this.productState.posX = 0;
        this.productState.posY = 0;
        this.productState.scale = 1.0;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        this.history.pushProductState('Centered Product Position', this.productState);
        this.syncFormFields();
        this.showToast('Product centered', 'info');
      });
    }

    // 6. Product Form Bindings
    const bindProductInput = (elementId, stateKey, label) => {
      const el = document.getElementById(elementId);
      if (!el) return;
      el.addEventListener('input', () => {
        this.productState[stateKey] = el.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      el.addEventListener('change', () => {
        this.history.pushProductState(`Changed ${label} to "${el.value}"`, this.productState);
      });
    };

    bindProductInput('inputProdTitle', 'name', 'Product Title');
    bindProductInput('inputProdDesc', 'description', 'Description');
    bindProductInput('inputProdPrice', 'price', 'Display Price');
    bindProductInput('inputProdOriginalPrice', 'originalPrice', 'Original Price');
    bindProductInput('inputProdBadge', 'badge', 'Promotional Badge');

    document.querySelectorAll('.quick-badge').forEach(badgeBtn => {
      badgeBtn.addEventListener('click', () => {
        const text = badgeBtn.textContent;
        this.productState.badge = text;
        const badgeInput = document.getElementById('inputProdBadge');
        if (badgeInput) badgeInput.value = text;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        this.history.pushProductState(`Set Badge to "${text}"`, this.productState);
      });
    });

    const inputProdScale = document.getElementById('inputProdScale');
    const scaleDisplay = document.getElementById('scaleDisplay');
    if (inputProdScale && scaleDisplay) {
      inputProdScale.addEventListener('input', () => {
        const scaleVal = parseFloat(inputProdScale.value) / 100;
        this.productState.scale = scaleVal;
        scaleDisplay.textContent = `${inputProdScale.value}%`;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputProdScale.addEventListener('change', () => {
        this.history.pushProductState(`Resized Product to ${inputProdScale.value}%`, this.productState);
      });
    }

    // 7. Master Brand Form Inputs (Protected if Locked!)
    const bindBrandInput = (elementId, stateKey, label) => {
      const el = document.getElementById(elementId);
      if (!el) return;
      el.addEventListener('input', () => {
        if (!this.isBrandModeUnlocked) {
          this.showToast('Unlock Brand Mode to edit brand styling', 'warning');
          this.syncFormFields();
          return;
        }
        this.brandState[stateKey] = el.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      el.addEventListener('change', () => {
        if (!this.isBrandModeUnlocked) return;
        this.history.pushBrandState(`Updated Brand ${label}`, this.brandState);
      });
    };

    bindBrandInput('inputBrandName', 'name', 'Name');
    bindBrandInput('inputBrandTagline', 'tagline', 'Tagline');
    bindBrandInput('inputBrandHandle', 'handle', 'Handle');
    bindBrandInput('inputBrandLogo', 'logoMonogram', 'Logo Monogram');
    bindBrandInput('selectFrameStyle', 'frameStyle', 'Frame Style');

    const inputAccentColor = document.getElementById('inputAccentColor');
    const accentHexDisplay = document.getElementById('accentHexDisplay');
    if (inputAccentColor && accentHexDisplay) {
      inputAccentColor.addEventListener('input', () => {
        if (!this.isBrandModeUnlocked) {
          this.showToast('Unlock Brand Mode to change colors', 'warning');
          inputAccentColor.value = this.brandState.accentColor;
          return;
        }
        this.brandState.accentColor = inputAccentColor.value;
        accentHexDisplay.textContent = inputAccentColor.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputAccentColor.addEventListener('change', () => {
        if (!this.isBrandModeUnlocked) return;
        this.history.pushBrandState('Changed Accent Color', this.brandState);
      });
    }

    const inputTextColor = document.getElementById('inputTextColor');
    const textHexDisplay = document.getElementById('textHexDisplay');
    if (inputTextColor && textHexDisplay) {
      inputTextColor.addEventListener('input', () => {
        if (!this.isBrandModeUnlocked) {
          this.showToast('Unlock Brand Mode to change text color', 'warning');
          inputTextColor.value = this.brandState.textColor;
          return;
        }
        this.brandState.textColor = inputTextColor.value;
        textHexDisplay.textContent = inputTextColor.value;
        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
      });
      inputTextColor.addEventListener('change', () => {
        if (!this.isBrandModeUnlocked) return;
        this.history.pushBrandState('Changed Text Color', this.brandState);
      });
    }

    const templateSelect = document.getElementById('templateSelect');
    if (templateSelect) {
      templateSelect.addEventListener('change', () => {
        const idx = parseInt(templateSelect.value, 10);
        this.applyTemplate(idx);
      });
    }

    document.querySelectorAll('.ratio-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.ratio-btn').forEach(b => {
          b.classList.remove('active', 'bg-cyan-600', 'text-white', 'font-semibold');
          b.classList.add('text-slate-400');
        });
        btn.classList.add('active', 'bg-cyan-600', 'text-white', 'font-semibold');
        btn.classList.remove('text-slate-400');
        const ratio = btn.getAttribute('data-ratio');
        this.setAspectRatio(ratio);
      });
    });

    const btnDownloadPng = document.getElementById('btnDownloadPng');
    const btnDownloadJpg = document.getElementById('btnDownloadJpg');
    const btnCopyClipboard = document.getElementById('btnCopyClipboard');

    if (btnDownloadPng) btnDownloadPng.addEventListener('click', () => this.exportImage('png'));
    if (btnDownloadJpg) btnDownloadJpg.addEventListener('click', () => this.exportImage('jpeg'));
    if (btnCopyClipboard) btnCopyClipboard.addEventListener('click', () => this.copyToClipboard());
  }

  async triggerAiGeneration() {
    const promptInput = document.getElementById('aiPromptInput');
    const prompt = promptInput ? promptInput.value.trim() : '';

    if (!prompt) {
      this.showToast('Please type a prompt first or click an inspiration chip!', 'warning');
      if (promptInput) promptInput.focus();
      return;
    }

    const selectedScope = document.querySelector('input[name="aiScope"]:checked')?.value || 'product-only';

    const btn = document.getElementById('btnAiGenerate');
    const spinner = document.getElementById('aiBtnSpinner');
    const icon = document.getElementById('aiBtnIcon');
    const text = document.getElementById('aiBtnText');

    if (btn) btn.disabled = true;
    if (spinner) spinner.classList.remove('hidden');
    if (icon) icon.classList.add('hidden');
    if (text) text.textContent = 'AI is styling your creative...';

    try {
      await new Promise(r => setTimeout(r, 600));

      const result = await this.aiEngine.generateFromPrompt(prompt, selectedScope, this.brandState, SAMPLE_PRODUCTS);

      if (result && result.product) {
        this.productState = {
          ...this.productState,
          ...result.product,
          imageUrl: null
        };

        if (selectedScope === 'full-creative' && result.brand) {
          this.brandState = {
            ...this.brandState,
            ...result.brand
          };
          this.history.pushBrandState(`AI Created Brand: ${result.brand.name}`, this.brandState);
        }

        this.history.pushProductState(`AI Generated: ${result.product.name}`, this.productState);

        this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
        this.canvasEngine.requestRender();
        this.syncFormFields();

        const resultCard = document.getElementById('aiResultCard');
        const resultName = document.getElementById('aiResultName');
        const resultPrice = document.getElementById('aiResultPrice');
        const resultBadge = document.getElementById('aiResultBadge');
        const resultDesc = document.getElementById('aiResultDesc');

        if (resultCard) {
          resultCard.classList.remove('hidden');
          if (resultName) resultName.textContent = result.product.name;
          if (resultPrice) resultPrice.textContent = result.product.originalPrice ? `${result.product.price} (Was ${result.product.originalPrice})` : result.product.price;
          if (resultBadge) resultBadge.textContent = result.product.badge;
          if (resultDesc) resultDesc.textContent = result.product.description;
        }

        this.showToast(`✨ AI Generated: ${result.product.name} (Live on Canvas!)`, 'success');
      }
    } catch (err) {
      console.error('AI generation error:', err);
      this.showToast('AI generation encountered an error', 'warning');
    } finally {
      if (btn) btn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
      if (icon) icon.classList.remove('hidden');
      if (text) text.textContent = 'Generate Creative with AI';
    }
  }

  handleUndo() {
    const result = this.history.undo(this.isBrandModeUnlocked, this.productState, this.brandState);
    if (!result) return;
    if (result.type === 'product') this.productState = result.state;
    else if (result.type === 'brand') this.brandState = result.state;

    this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
    this.syncFormFields();
  }

  handleRedo() {
    const result = this.history.redo(this.isBrandModeUnlocked);
    if (!result) return;
    if (result.type === 'product') this.productState = result.state;
    else if (result.type === 'brand') this.brandState = result.state;

    this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
    this.syncFormFields();
  }

  applySampleProduct(prodId) {
    const prod = SAMPLE_PRODUCTS.find(p => p.id === prodId);
    if (!prod) return;

    this.productState.name = prod.name;
    this.productState.price = prod.price;
    this.productState.originalPrice = prod.originalPrice;
    this.productState.badge = prod.badge;
    this.productState.badgeColor = prod.badgeColor;
    this.productState.description = prod.description;
    this.productState.svgDataUrl = svgToDataUrl(prod.svg);
    this.productState.imageUrl = null;
    this.productState.posX = 0;
    this.productState.posY = 10;
    this.productState.scale = 0.95;

    this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
    this.history.pushProductState(`Swapped to ${prod.name}`, this.productState);
    this.syncFormFields();
    this.showToast(`Swapped to ${prod.name} (Brand layout preserved 🛡️)`, 'success');
  }

  applyTemplate(index) {
    const t = BRAND_TEMPLATES[index];
    if (!t) return;

    this.currentTemplateIndex = index;
    this.currentTemplate = t;
    this.brandState = JSON.parse(JSON.stringify(t.brand));

    const sample = SAMPLE_PRODUCTS.find(p => p.id === t.defaultProduct.sampleId) || SAMPLE_PRODUCTS[0];
    this.productState = {
      ...JSON.parse(JSON.stringify(t.defaultProduct)),
      svgDataUrl: svgToDataUrl(sample.svg),
      imageUrl: null
    };

    this.history.pushBrandState(`Switched Theme to ${t.name}`, this.brandState);
    this.history.pushProductState(`Loaded ${t.name} Product Preset`, this.productState);
    this.canvasEngine.setState(this.brandState, this.productState, this.isBrandModeUnlocked);
    this.syncFormFields();
    this.showToast(`Applied Theme: ${t.name}`, 'info');
  }

  setAspectRatio(ratio) {
    this.currentAspectRatio = ratio;
    const canvas = document.getElementById('mainCanvas');
    if (!canvas) return;

    canvas.classList.remove('aspect-square', 'aspect-[9/16]', 'aspect-video');

    if (ratio === '1:1') {
      canvas.classList.add('aspect-square');
      this.canvasEngine.setDimensions(1080, 1080);
    } else if (ratio === '9:16') {
      canvas.classList.add('aspect-[9/16]');
      this.canvasEngine.setDimensions(1080, 1920);
    } else if (ratio === '16:9') {
      canvas.classList.add('aspect-video');
      this.canvasEngine.setDimensions(1920, 1080);
    }
    this.showToast(`Canvas Format: ${ratio}`, 'info');
  }

  updateModeUI() {
    const modeToggleBtn = document.getElementById('modeToggleBtn');
    const modeLockIcon = document.getElementById('modeLockIcon');
    const modeStatusLabel = document.getElementById('modeStatusLabel');
    const brandLockCardIcon = document.getElementById('brandLockCardIcon');
    const lockStatusMessage = document.getElementById('lockStatusMessage');
    const brandLockCheckbox = document.getElementById('brandLockCheckbox');

    if (this.isBrandModeUnlocked) {
      if (modeToggleBtn) {
        modeToggleBtn.classList.remove('bg-emerald-500/10', 'border-emerald-500/30', 'text-emerald-400', 'brand-locked-pulse');
        modeToggleBtn.classList.add('bg-amber-500/10', 'border-amber-500/40', 'text-amber-400');
      }
      if (modeLockIcon) modeLockIcon.textContent = '🔓';
      if (modeStatusLabel) modeStatusLabel.textContent = 'BRAND DESIGN MODE (Unlocked)';
      if (brandLockCardIcon) brandLockCardIcon.textContent = '🔓';
      if (lockStatusMessage) {
        lockStatusMessage.textContent = '⚠️ Master Brand is unlocked. Edits here change the template aesthetic.';
        lockStatusMessage.className = 'text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20';
      }
      if (brandLockCheckbox) brandLockCheckbox.checked = false;
    } else {
      if (modeToggleBtn) {
        modeToggleBtn.classList.remove('bg-amber-500/10', 'border-amber-500/40', 'text-amber-400');
        modeToggleBtn.classList.add('bg-emerald-500/10', 'border-emerald-500/30', 'text-emerald-400', 'brand-locked-pulse');
      }
      if (modeLockIcon) modeLockIcon.textContent = '🔒';
      if (modeStatusLabel) modeStatusLabel.textContent = 'BRAND LOCKED (Safe Mode)';
      if (brandLockCardIcon) brandLockCardIcon.textContent = '🔒';
      if (lockStatusMessage) {
        lockStatusMessage.textContent = '✓ Brand layout is securely frozen. All product updates and undos are safe.';
        lockStatusMessage.className = 'text-[11px] text-emerald-400 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20';
      }
      if (brandLockCheckbox) brandLockCheckbox.checked = true;
    }
  }

  updateHistoryUI(status) {
    const btnUndo = document.getElementById('btnUndo');
    const btnRedo = document.getElementById('btnRedo');

    const canUndo = this.history.canUndo(this.isBrandModeUnlocked);
    const canRedo = this.history.canRedo(this.isBrandModeUnlocked);

    if (btnUndo) btnUndo.disabled = !canUndo;
    if (btnRedo) btnRedo.disabled = !canRedo;

    const listContainer = document.getElementById('historyListContainer');
    const historyCount = document.getElementById('historyActionCount');
    const logs = this.history.getHistoryLogs(this.isBrandModeUnlocked);

    if (historyCount) historyCount.textContent = `${logs.length} step${logs.length === 1 ? '' : 's'}`;

    if (listContainer) {
      listContainer.innerHTML = logs.map(item => `
        <div class="p-2.5 rounded-lg border ${item.isCurrent ? 'bg-cyan-500/10 border-cyan-500/40' : 'bg-slate-900/60 border-white/5'} flex items-center justify-between text-xs">
          <div class="flex items-center space-x-2">
            <span class="${item.isCurrent ? 'text-cyan-400 font-bold' : 'text-slate-500'} font-mono text-[10px]">#${item.index + 1}</span>
            <span class="${item.isCurrent ? 'text-white font-semibold' : 'text-slate-300'}">${item.label}</span>
          </div>
          <span class="text-[10px] text-slate-500">${item.time}</span>
        </div>
      `).join('');
    }
  }

  syncFormFields() {
    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.value = val || '';
    };

    setVal('inputProdTitle', this.productState.name);
    setVal('inputProdDesc', this.productState.description);
    setVal('inputProdPrice', this.productState.price);
    setVal('inputProdOriginalPrice', this.productState.originalPrice);
    setVal('inputProdBadge', this.productState.badge);

    const scaleVal = Math.round((this.productState.scale || 1.0) * 100);
    setVal('inputProdScale', scaleVal);
    const scaleDisplay = document.getElementById('scaleDisplay');
    if (scaleDisplay) scaleDisplay.textContent = `${scaleVal}%`;

    setVal('inputBrandName', this.brandState.name);
    setVal('inputBrandTagline', this.brandState.tagline);
    setVal('inputBrandHandle', this.brandState.handle);
    setVal('inputBrandLogo', this.brandState.logoMonogram);
    setVal('selectFrameStyle', this.brandState.frameStyle || 'ornate-border');

    setVal('inputAccentColor', this.brandState.accentColor || '#d4af37');
    const accentHex = document.getElementById('accentHexDisplay');
    if (accentHex) accentHex.textContent = this.brandState.accentColor || '#d4af37';

    setVal('inputTextColor', this.brandState.textColor || '#ffffff');
    const textHex = document.getElementById('textHexDisplay');
    if (textHex) textHex.textContent = this.brandState.textColor || '#ffffff';
  }

  exportImage(format = 'png') {
    const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const ext = format === 'jpeg' ? 'jpg' : 'png';
    const dataUrl = this.canvasEngine.exportDataUrl(mimeType, 0.95);

    const filename = `layer-lab-${(this.productState.name || 'product').toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}.${ext}`;

    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    this.showToast(`Exported high-res ${ext.toUpperCase()} successfully!`, 'success');
  }

  async copyToClipboard() {
    try {
      this.canvasEngine.render(true);
      const canvas = document.getElementById('mainCanvas');
      if (!canvas) return;

      canvas.toBlob(async (blob) => {
        if (!blob) {
          this.showToast('Failed to copy canvas', 'warning');
          return;
        }
        try {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob })
          ]);
          this.showToast('Copied high-res image to clipboard!', 'success');
        } catch (err) {
          this.showToast('Clipboard access restricted in this browser context', 'info');
        } finally {
          this.canvasEngine.resizeCanvas();
          this.canvasEngine.requestRender();
        }
      }, 'image/png', 0.95);
    } catch (e) {
      this.showToast('Could not copy image to clipboard', 'warning');
    }
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    const colors = {
      success: 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200 shadow-emerald-900/30',
      warning: 'bg-amber-950/90 border-amber-500/50 text-amber-200 shadow-amber-900/30',
      info: 'bg-slate-900/90 border-cyan-500/40 text-cyan-200 shadow-cyan-900/30'
    };
    const icons = { success: '🛡️', warning: '⚠️', info: '✨' };

    toast.className = `flex items-center space-x-2.5 px-4 py-2.5 rounded-xl border backdrop-blur-md shadow-xl text-xs transition-all duration-300 transform translate-y-3 opacity-0 ${colors[type] || colors.info}`;
    toast.innerHTML = `
      <span class="text-sm">${icons[type] || '✨'}</span>
      <span class="font-medium">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('translate-y-3', 'opacity-0');
      toast.classList.add('translate-y-0', 'opacity-100');
    }, 10);

    setTimeout(() => {
      toast.classList.remove('translate-y-0', 'opacity-100');
      toast.classList.add('translate-y-3', 'opacity-0');
      setTimeout(() => toast.remove(), 350);
    }, 3200);
  }
}
