@echo off
title Launching Layer Lab Studio...
start "" "%~dp0index.html"
exit
