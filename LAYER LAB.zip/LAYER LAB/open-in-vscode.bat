@echo off
title Opening Layer Lab in VS Code...
start "" "%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe" "%~dp0."
exit
