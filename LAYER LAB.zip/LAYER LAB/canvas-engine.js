// Layer Lab - Canvas Engine
// Renders the protected Brand Layer (static) and the dynamic Product Layer with high-DPI scaling

export class CanvasEngine {
  constructor(canvasElement, options = {}) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext('2d');
    
    // Internal logical canvas resolution (standard 1080x1080 square)
    this.baseWidth = 1080;
    this.baseHeight = 1080;

    // State references
    this.brandState = null;
    this.productState = null;
    this.isBrandModeUnlocked = false;
    
    // Selection & interaction
    this.selectedElement = 'product-image'; // 'product-image', 'product-price', 'product-badge', 'product-text'
    this.isDragging = false;
    this.isResizing = false;
    this.dragStart = { x: 0, y: 0 };
    this.activeHandle = null;

    // Image cache to avoid reloading on each frame
    this.imageCache = new Map();
    this.logoCache = null;

    // Callbacks
    this.onStateModified = options.onStateModified || (() => {});
    this.onSelectionChange = options.onSelectionChange || (() => {});

    this.setupInteractions();
  }

  setDimensions(width, height) {
    this.baseWidth = width;
    this.baseHeight = height;
    this.resizeCanvas();
    this.requestRender();
  }

  resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    
    // Physical pixel buffer
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    
    // Normalize coordinate system to logical dimensions
    this.scaleFactorX = (rect.width * dpr) / this.baseWidth;
    this.scaleFactorY = (rect.height * dpr) / this.baseHeight;
  }

  setState(brandState, productState, isBrandModeUnlocked = false) {
    this.brandState = brandState;
    this.productState = productState;
    this.isBrandModeUnlocked = isBrandModeUnlocked;
    this.requestRender();
  }

  requestRender() {
    requestAnimationFrame(() => this.render(false));
  }

  async loadImage(src) {
    if (!src) return null;
    if (this.imageCache.has(src)) {
      return this.imageCache.get(src);
    }

    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        this.imageCache.set(src, img);
        resolve(img);
      };
      img.onerror = () => resolve(null);
      img.src = src;
    });
  }

  // Convert client mouse/touch coordinates to internal 1080p canvas coordinates
  getCanvasCoords(e) {
    const rect = this.canvas.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX);
    const clientY = e.clientY || (e.touches && e.touches[0].clientY);
    
    const x = ((clientX - rect.left) / rect.width) * this.baseWidth;
    const y = ((clientY - rect.top) / rect.height) * this.baseHeight;
    return { x, y };
  }

  setupInteractions() {
    const handleDown = (e) => {
      const coords = this.getCanvasCoords(e);
      const hit = this.hitTest(coords.x, coords.y);

      if (hit) {
        if (hit.handle) {
          this.isResizing = true;
          this.activeHandle = hit.handle;
        } else {
          this.isDragging = true;
          this.selectedElement = hit.element;
          this.onSelectionChange(this.selectedElement);
        }
        this.dragStart = coords;
        this.requestRender();
      } else {
        // Deselect if clicked in empty space
        this.selectedElement = null;
        this.onSelectionChange(null);
        this.requestRender();
      }
    };

    const handleMove = (e) => {
      const coords = this.getCanvasCoords(e);

      if (this.isDragging && this.selectedElement) {
        const dx = coords.x - this.dragStart.x;
        const dy = coords.y - this.dragStart.y;

        if (this.selectedElement === 'product-image') {
          this.productState.posX = (this.productState.posX || 0) + dx;
          this.productState.posY = (this.productState.posY || 0) + dy;
        } else if (this.selectedElement === 'product-price') {
          this.productState.pricePosX = (this.productState.pricePosX || 0) + dx;
          this.productState.pricePosY = (this.productState.pricePosY || 0) + dy;
        } else if (this.selectedElement === 'product-badge') {
          this.productState.badgePosX = (this.productState.badgePosX || 0) + dx;
          this.productState.badgePosY = (this.productState.badgePosY || 0) + dy;
        }

        this.dragStart = coords;
        this.requestRender();
      } else if (this.isResizing && this.selectedElement === 'product-image') {
        const dx = coords.x - this.dragStart.x;
        const scaleDelta = dx / 350;
        const newScale = Math.min(Math.max(0.4, (this.productState.scale || 1) + scaleDelta), 2.2);
        this.productState.scale = newScale;
        this.dragStart = coords;
        this.requestRender();
      } else {
        // Change cursor based on hover
        const hit = this.hitTest(coords.x, coords.y);
        if (hit && hit.handle) {
          this.canvas.style.cursor = 'nwse-resize';
        } else if (hit) {
          this.canvas.style.cursor = 'move';
        } else {
          this.canvas.style.cursor = 'default';
        }
      }
    };

    const handleUp = () => {
      if (this.isDragging || this.isResizing) {
        this.isDragging = false;
        this.isResizing = false;
        this.activeHandle = null;
        this.onStateModified('Adjusted Product Layout');
      }
    };

    this.canvas.addEventListener('mousedown', handleDown);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);

    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      handleDown(e);
    }, { passive: false });

    window.addEventListener('touchmove', (e) => {
      if (this.isDragging || this.isResizing) {
        e.preventDefault();
      }
      handleMove(e);
    }, { passive: false });

    window.addEventListener('touchend', handleUp);
  }

  // Hit testing for product elements (Brand elements are protected!)
  hitTest(x, y) {
    if (!this.productState) return null;

    // Check resize handles for selected product image
    if (this.selectedElement === 'product-image') {
      const bounds = this.getProductImageBounds();
      const handleRadius = 24;
      // Bottom-right handle
      const brX = bounds.x + bounds.w;
      const brY = bounds.y + bounds.h;
      if (Math.hypot(x - brX, y - brY) <= handleRadius) {
        return { handle: 'br', element: 'product-image' };
      }
    }

    // Hit test Product Image
    const pBounds = this.getProductImageBounds();
    if (x >= pBounds.x && x <= pBounds.x + pBounds.w && y >= pBounds.y && y <= pBounds.y + pBounds.h) {
      return { element: 'product-image' };
    }

    // Hit test Price Tag
    const priceBounds = this.getPriceBounds();
    if (x >= priceBounds.x && x <= priceBounds.x + priceBounds.w && y >= priceBounds.y && y <= priceBounds.y + priceBounds.h) {
      return { element: 'product-price' };
    }

    // Hit test Badge
    const badgeBounds = this.getBadgeBounds();
    if (x >= badgeBounds.x && x <= badgeBounds.x + badgeBounds.w && y >= badgeBounds.y && y <= badgeBounds.y + badgeBounds.h) {
      return { element: 'product-badge' };
    }

    return null;
  }

  getProductImageBounds() {
    const scale = this.productState.scale || 1.0;
    const baseW = 540 * scale;
    const baseH = 540 * scale;
    const cx = (this.baseWidth / 2) + (this.productState.posX || 0);
    const cy = (this.baseHeight * 0.46) + (this.productState.posY || 0);

    return {
      x: cx - baseW / 2,
      y: cy - baseH / 2,
      w: baseW,
      h: baseH,
      cx,
      cy
    };
  }

  getPriceBounds() {
    const defX = this.baseWidth / 2 + (this.productState.pricePosX || 0);
    const defY = this.baseHeight * 0.77 + (this.productState.pricePosY || 0);
    const w = 340;
    const h = 75;
    return { x: defX - w / 2, y: defY - h / 2, w, h };
  }

  getBadgeBounds() {
    const placement = this.brandState?.badgePlacement || 'top-right';
    let defX = placement === 'top-left' ? 140 : this.baseWidth - 140;
    let defY = 220;

    defX += (this.productState.badgePosX || 0);
    defY += (this.productState.badgePosY || 0);

    const w = 220;
    const h = 54;
    return { x: defX - w / 2, y: defY - h / 2, w, h };
  }

  // Main Render Loop
  async render(isExport = false) {
    if (!this.brandState || !this.productState) return;

    const ctx = this.ctx;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = isExport ? 2 : (window.devicePixelRatio || 1);

    if (isExport) {
      // Export at pristine double resolution
      this.canvas.width = this.baseWidth * 2;
      this.canvas.height = this.baseHeight * 2;
      ctx.scale(2, 2);
    } else {
      this.canvas.width = rect.width * dpr;
      this.canvas.height = rect.height * dpr;
      ctx.scale(this.canvas.width / this.baseWidth, this.canvas.height / this.baseHeight);
    }

    // Clear Canvas
    ctx.clearRect(0, 0, this.baseWidth, this.baseHeight);

    // ==========================================
    // LAYER 1: MASTER BRAND LAYER (PROTECTED & STATIC)
    // ==========================================
    this.renderBrandLayer(ctx);

    // ==========================================
    // LAYER 2: DYNAMIC PRODUCT LAYER (EDITABLE & SAFE)
    // ==========================================
    await this.renderProductLayer(ctx);

    // Draw selection handles only in interactive edit mode (never on export)
    if (!isExport && this.selectedElement) {
      this.renderSelectionOutline(ctx);
    }
  }

  // --- BRAND LAYER RENDERING ---
  renderBrandLayer(ctx) {
    const b = this.brandState;
    const W = this.baseWidth;
    const H = this.baseHeight;

    // 1. Background Fill / Gradient
    if (b.backgroundType === 'gradient' || b.bgGradientStart) {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, b.bgGradientStart || '#18181b');
      grad.addColorStop(1, b.bgGradientEnd || '#09090b');
      ctx.fillStyle = grad;
    } else {
      ctx.fillStyle = b.bgGradientStart || '#18181b';
    }
    ctx.fillRect(0, 0, W, H);

    // Subtle luxury background grain/radial glow
    const radial = ctx.createRadialGradient(W / 2, H * 0.45, 80, W / 2, H * 0.45, 600);
    radial.addColorStop(0, `${b.accentColor}18`);
    radial.addColorStop(1, 'transparent');
    ctx.fillStyle = radial;
    ctx.fillRect(0, 0, W, H);

    // 2. Brand Frame & Border Style
    this.renderBrandFrame(ctx, b, W, H);

    // 3. Brand Header (Monogram + Brand Name + Tagline)
    ctx.save();
    ctx.textAlign = 'center';

    // Monogram / Logo Mark
    if (b.logoMonogram) {
      ctx.fillStyle = b.accentColor;
      ctx.font = `600 24px ${b.fontHeader || 'sans-serif'}`;
      ctx.fillText(b.logoMonogram.toUpperCase(), W / 2, 85);
    }

    // Brand Name
    ctx.fillStyle = b.textColor || '#ffffff';
    ctx.font = `700 38px ${b.fontFamily || 'serif'}`;
    // Add subtle shadow for luxury presence
    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 6;
    ctx.fillText(b.name.toUpperCase(), W / 2, 130);
    ctx.shadowBlur = 0;

    // Brand Tagline / Subtitle
    ctx.fillStyle = `${b.textColor}99`; // 60% opacity
    ctx.font = `500 15px ${b.fontHeader || 'sans-serif'}`;
    ctx.letterSpacing = '3px';
    ctx.fillText(b.tagline.toUpperCase(), W / 2, 158);
    ctx.restore();

    // 4. Subtle Watermark / Brand Stamp
    if (b.showWatermark && b.watermarkText) {
      ctx.save();
      ctx.translate(W * 0.88, H * 0.38);
      ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center';
      ctx.font = `700 13px ${b.fontHeader || 'sans-serif'}`;
      ctx.fillStyle = `${b.textColor}22`; // very subtle watermark
      ctx.fillText(b.watermarkText.toUpperCase(), 0, 0);
      ctx.restore();
    }

    // 5. Brand Footer & Social Handle
    ctx.save();
    // Divider line
    ctx.strokeStyle = `${b.accentColor}40`;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(W * 0.2, H - 75);
    ctx.lineTo(W * 0.8, H - 75);
    ctx.stroke();

    // Handle text
    ctx.textAlign = 'center';
    ctx.fillStyle = `${b.textColor}bb`;
    ctx.font = `500 16px ${b.fontHeader || 'sans-serif'}`;
    ctx.fillText(b.handle, W / 2, H - 45);
    ctx.restore();
  }

  renderBrandFrame(ctx, b, W, H) {
    const style = b.frameStyle || 'ornate-border';
    ctx.save();

    if (style === 'ornate-border') {
      // Outer border
      ctx.strokeStyle = `${b.accentColor}55`;
      ctx.lineWidth = 2;
      ctx.strokeRect(35, 35, W - 70, H - 70);

      // Inner thin border
      ctx.strokeStyle = `${b.accentColor}25`;
      ctx.lineWidth = 1;
      ctx.strokeRect(45, 45, W - 90, H - 90);

      // Decorative corner accents
      const cornerSize = 25;
      ctx.strokeStyle = b.accentColor;
      ctx.lineWidth = 3;

      // Top-Left
      ctx.beginPath();
      ctx.moveTo(35, 35 + cornerSize);
      ctx.lineTo(35, 35);
      ctx.lineTo(35 + cornerSize, 35);
      ctx.stroke();

      // Top-Right
      ctx.beginPath();
      ctx.moveTo(W - 35 - cornerSize, 35);
      ctx.lineTo(W - 35, 35);
      ctx.lineTo(W - 35, 35 + cornerSize);
      ctx.stroke();

      // Bottom-Left
      ctx.beginPath();
      ctx.moveTo(35, H - 35 - cornerSize);
      ctx.lineTo(35, H - 35);
      ctx.lineTo(35 + cornerSize, H - 35);
      ctx.stroke();

      // Bottom-Right
      ctx.beginPath();
      ctx.moveTo(W - 35 - cornerSize, H - 35);
      ctx.lineTo(W - 35, H - 35);
      ctx.lineTo(W - 35, H - 35 - cornerSize);
      ctx.stroke();

    } else if (style === 'minimal-frame') {
      ctx.strokeStyle = `${b.accentColor}44`;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(40, 40, W - 80, H - 80);
    } else if (style === 'modern-card') {
      // Sleek rounded container card for product focus
      ctx.strokeStyle = `${b.accentColor}33`;
      ctx.lineWidth = 2;
      this.drawRoundedRect(ctx, 30, 30, W - 60, H - 60, 24);
      ctx.stroke();
    }

    ctx.restore();
  }

  // --- PRODUCT LAYER RENDERING ---
  async renderProductLayer(ctx) {
    const p = this.productState;
    const b = this.brandState;
    const W = this.baseWidth;
    const H = this.baseHeight;

    // 1. Render Product Image / Graphic
    const bounds = this.getProductImageBounds();
    const imgSrc = p.imageUrl || p.svgDataUrl;

    if (imgSrc) {
      const img = await this.loadImage(imgSrc);
      if (img) {
        ctx.save();
        // Product Drop Shadow for high-end look
        ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
        ctx.shadowBlur = 28;
        ctx.shadowOffsetY = 18;

        ctx.drawImage(img, bounds.x, bounds.y, bounds.w, bounds.h);
        ctx.restore();
      }
    }

    // 2. Render Promotional Badge (e.g., 'NEW ARRIVAL', '50% OFF')
    if (p.badge) {
      const badgeBounds = this.getBadgeBounds();
      ctx.save();
      const badgeBg = p.badgeColor || b.badgeBgColor || b.accentColor;
      const badgeText = p.badgeTextColor || b.badgeTextColor || '#ffffff';

      // Badge Drop shadow
      ctx.shadowColor = 'rgba(0,0,0,0.3)';
      ctx.shadowBlur = 12;
      ctx.shadowOffsetY = 4;

      ctx.fillStyle = badgeBg;
      this.drawRoundedRect(ctx, badgeBounds.x, badgeBounds.y, badgeBounds.w, badgeBounds.h, 27);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Badge Text
      ctx.fillStyle = badgeText;
      ctx.font = `700 16px ${b.fontHeader || 'sans-serif'}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(p.badge.toUpperCase(), badgeBounds.x + badgeBounds.w / 2, badgeBounds.y + badgeBounds.h / 2);
      ctx.restore();
    }

    // 3. Render Product Title & Brief
    ctx.save();
    ctx.textAlign = 'center';
    ctx.fillStyle = b.textColor || '#ffffff';
    ctx.font = `700 32px ${b.fontFamily || 'serif'}`;
    const titleY = H * 0.70 + (p.posY || 0) * 0.3;
    ctx.fillText(p.name, W / 2, titleY);

    if (p.description) {
      ctx.fillStyle = `${b.textColor}aa`;
      ctx.font = `400 16px ${b.fontHeader || 'sans-serif'}`;
      ctx.fillText(p.description, W / 2, titleY + 30);
    }
    ctx.restore();

    // 4. Render Price Tag Badge
    if (p.price) {
      const pb = this.getPriceBounds();
      ctx.save();
      // Frosted / dark pill background
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.strokeStyle = `${b.accentColor}66`;
      ctx.lineWidth = 1.5;
      this.drawRoundedRect(ctx, pb.x, pb.y, pb.w, pb.h, 38);
      ctx.fill();
      ctx.stroke();

      // Current Price
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = b.accentColor || '#ffffff';
      ctx.font = `800 30px ${b.fontHeader || 'sans-serif'}`;
      
      if (p.originalPrice) {
        // Render with discount strike-through
        ctx.textAlign = 'left';
        const startX = pb.x + 35;
        ctx.fillText(p.price, startX, pb.y + pb.h / 2);

        // Strikethrough price
        ctx.fillStyle = `${b.textColor}66`;
        ctx.font = `500 20px ${b.fontHeader || 'sans-serif'}`;
        const strikeX = startX + ctx.measureText(p.price).width + 30;
        ctx.fillText(p.originalPrice, strikeX, pb.y + pb.h / 2);

        // Strike line
        const strikeW = ctx.measureText(p.originalPrice).width;
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(strikeX - 2, pb.y + pb.h / 2);
        ctx.lineTo(strikeX + strikeW + 2, pb.y + pb.h / 2);
        ctx.stroke();
      } else {
        // Centered single price
        ctx.fillText(p.price, pb.x + pb.w / 2, pb.y + pb.h / 2);
      }
      ctx.restore();
    }
  }

  // Draw Selection Handles
  renderSelectionOutline(ctx) {
    let bounds = null;
    if (this.selectedElement === 'product-image') {
      bounds = this.getProductImageBounds();
    } else if (this.selectedElement === 'product-price') {
      bounds = this.getPriceBounds();
    } else if (this.selectedElement === 'product-badge') {
      bounds = this.getBadgeBounds();
    }

    if (!bounds) return;

    ctx.save();
    // Bounding Box
    ctx.strokeStyle = '#38bdf8'; // vivid cyan
    ctx.lineWidth = 2.5;
    ctx.setLineDash([6, 6]);
    ctx.strokeRect(bounds.x - 6, bounds.y - 6, bounds.w + 12, bounds.h + 12);
    ctx.setLineDash([]);

    // Transform corner handles (only on product image)
    if (this.selectedElement === 'product-image') {
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      const hSize = 14;

      // Bottom Right resize handle
      const brX = bounds.x + bounds.w + 6;
      const brY = bounds.y + bounds.h + 6;
      ctx.fillRect(brX - hSize / 2, brY - hSize / 2, hSize, hSize);
      ctx.strokeRect(brX - hSize / 2, brY - hSize / 2, hSize, hSize);
    }
    ctx.restore();
  }

  drawRoundedRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  exportDataUrl(format = 'image/png', quality = 0.95) {
    // Render at crisp high quality
    this.render(true);
    const dataUrl = this.canvas.toDataURL(format, quality);
    // Restore editor resolution
    this.resizeCanvas();
    this.requestRender();
    return dataUrl;
  }
}
